/**
 * In-game calendar. Three sources:
 *  - "core":      Foundry's own calendar + world time (what dnd5e 5.x sets up, e.g. Harptos/Greyhawk)
 *  - "worldTime": your own month/weekday list driven by Foundry's world time
 *  - "manual":    you type the date in the designer
 */

export function parseMonths(text) {
  const months = [];
  for (const raw of String(text || "").split("\n")) {
    const line = raw.trim();
    if (!line) continue;
    const m = line.match(/^(.*?)\s*[:|,]\s*(\d+)\s*$/);
    months.push(m ? { name: m[1].trim(), days: Math.max(1, Number(m[2])) } : { name: line, days: 30 });
  }
  return months.length ? months : [{ name: "Month", days: 30 }];
}

export function parseWeekdays(text) {
  const days = String(text || "").split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
  return days.length ? days : ["Day"];
}

const mod = (a, n) => ((a % n) + n) % n;

/** Build a calendar state from an absolute day count since the epoch. */
function fromDayCount(dayCount, hour, minute, months, weekdays, yearOffset) {
  const yearLen = months.reduce((s, m) => s + m.days, 0);
  const yearIdx = Math.floor(dayCount / yearLen);
  let doy = mod(dayCount, yearLen);
  let monthIndex = 0;
  while (doy >= months[monthIndex].days) { doy -= months[monthIndex].days; monthIndex++; }
  const day = doy + 1;
  return {
    year: yearOffset + yearIdx,
    monthIndex,
    monthName: months[monthIndex].name,
    monthDays: months[monthIndex].days,
    day,
    weekdayIndex: mod(dayCount, weekdays.length),
    firstWeekdayIndex: mod(dayCount - (day - 1), weekdays.length),
    hour, minute
  };
}

/**
 * @param {object} cfg       layout.calendar
 * @param {object} env       { worldTime, core } — core is game.time (may be undefined)
 */
export function calendarState(cfg = {}, env = {}) {
  let st = null;

  if (cfg.source === "core" && env.core?.calendar && env.core?.components) {
    try { st = fromCore(env.core, env.localize ?? ((s) => s), Number(cfg.dayOffset) || 0, Number(cfg.yearAdjust) || 0); } catch (err) { st = null; }
  }

  if (!st) {
    const months = parseMonths(cfg.months);
    const weekdays = parseWeekdays(cfg.weekdays);
    const yearOffset = Number(cfg.yearOffset) || 0;
    if (cfg.source === "manual") {
      const m = cfg.manual || {};
      const monthIndex = Math.min(Math.max(1, Number(m.month) || 1), months.length) - 1;
      const day = Math.min(Math.max(1, Number(m.day) || 1), months[monthIndex].days);
      const yearLen = months.reduce((s, x) => s + x.days, 0);
      const before = months.slice(0, monthIndex).reduce((s, x) => s + x.days, 0);
      const dayCount = ((Number(m.year) || yearOffset) - yearOffset) * yearLen + before + day - 1;
      st = fromDayCount(dayCount, Number(m.hour) || 0, Number(m.minute) || 0, months, weekdays, yearOffset);
    } else {
      const wt = Number(env.worldTime) || 0;
      const totalMin = Math.floor(wt / 60) + (Number(cfg.startOffsetDays) || 0) * 1440;
      st = fromDayCount(Math.floor(totalMin / 1440), mod(Math.floor(totalMin / 60), 24), mod(totalMin, 60), months, weekdays, yearOffset);
    }
    st.weekdays = weekdays;
  }

  st.weekday = st.weekdays[st.weekdayIndex] ?? "";
  st.era = cfg.era ?? "";
  st.season = st.season || cfg.season || "";
  st.moon = cfg.moon || "";
  st.source = cfg.source;
  return st;
}

/** Foundry v13+ core calendar (game.time). */
function fromCore(time, localize, dayOffset, yearAdjust) {
  const c = time.components;
  const cal = time.calendar;
  const months = (cal.months?.values ?? []).map((m) => ({ name: localize(m.name), days: m.days ?? 30 }));
  const weekdays = (cal.days?.values ?? []).map((d) => localize(d.name));
  if (!months.length || !weekdays.length) throw new Error("no calendar data");
  const monthIndex = c.month ?? 0;
  const day = (c.dayOfMonth ?? 0) + 1 + dayOffset;
  const weekdayIndex = c.dayOfWeek ?? 0;
  const seasons = cal.seasons?.values ?? [];
  return {
    year: (c.year ?? 0) + yearAdjust,
    monthIndex,
    monthName: months[monthIndex]?.name ?? "",
    monthDays: months[monthIndex]?.days ?? 30,
    day,
    weekdayIndex,
    firstWeekdayIndex: mod(weekdayIndex - (day - 1), weekdays.length),
    hour: c.hour ?? 0,
    minute: c.minute ?? 0,
    season: c.season != null && seasons[c.season] ? localize(seasons[c.season].name) : "",
    weekdays
  };
}
