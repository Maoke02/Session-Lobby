import { MODULE_ID, defaultStore } from "./defaults.js";
import { Lobby } from "./lobby.js";
import { registerVault, registerVaultSocket, VaultApp } from "./vault.js";
import { registerMap, WorldMap } from "./map.js";
import { registerShops, onSessionLiveChanged, ShopsApp } from "./shops.js";
import { registerIntegrations, openQuestLog, openRelationships } from "./integrations.js";

/* ---------------------------------------------------------------------- */
/*  Settings                                                               */
/* ---------------------------------------------------------------------- */

Hooks.once("init", () => {
  registerVault();
  registerMap();
  registerShops();
  registerIntegrations();

  game.settings.register(MODULE_ID, "store", {
    scope: "world",
    config: false,
    type: Object,
    default: defaultStore(),
    onChange: () => Lobby.refresh()
  });

  game.settings.register(MODULE_ID, "sessionLive", {
    name: "Session is live",
    hint: "When off, everyone sees the lobby instead of the game. The GM's Start Session button flips this.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
    onChange: (live) => {
      Lobby.forced = false;
      Lobby.hiddenForMe = false;
      Lobby.refresh();
      if (!live) Lobby.quoteIndex = 0;
      onSessionLiveChanged();
    }
  });

  game.settings.register(MODULE_ID, "autoLobbyOnGMLeave", {
    name: "Return to lobby when the GM logs out",
    hint: "Players are sent back to the lobby if no GM is connected.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.registerMenu(MODULE_ID, "designer", {
    name: "Lobby Designer",
    label: "Open Designer",
    hint: "Build and edit the lobby page players see between sessions.",
    icon: "fa-solid fa-pen-ruler",
    type: class extends foundry.applications.api.ApplicationV2 {
      async render() {
        const { LobbyDesigner } = await import("./designer.js");
        LobbyDesigner.open();
        return this;
      }
    },
    restricted: true
  });

  game.keybindings.register(MODULE_ID, "toggleLobby", {
    name: "Show / hide the lobby",
    hint: "GM: start or end the session for everyone. Players: peek at the lobby.",
    editable: [{ key: "KeyL", modifiers: ["Control", "Shift"] }],
    onDown: () => { toggle(); return true; }
  });
});

/* ---------------------------------------------------------------------- */
/*  Lifecycle                                                              */
/* ---------------------------------------------------------------------- */

Hooks.once("ready", () => {
  registerVaultSocket();
  game.modules.get(MODULE_ID).api = {
    Lobby,
    open: () => { Lobby.forced = true; Lobby.hiddenForMe = false; Lobby.refresh(); },
    close: () => { Lobby.forced = false; Lobby.hiddenForMe = true; Lobby.refresh(); },
    startSession: () => Lobby.setLive(true),
    endSession: () => Lobby.setLive(false),
    designer: async () => (await import("./designer.js")).LobbyDesigner.open(),
    vault: () => VaultApp.open(),
    map: (zone) => WorldMap.open({ zone }),
    shops: () => ShopsApp.open(),
    questLog: () => openQuestLog(),
    relationships: (view = "picker") => openRelationships({ view })
  };
  Lobby.refresh();
});

const refreshMusic = foundry.utils.debounce(() => Lobby.updateMusic(), 100);
Hooks.on("updatePlaylist", refreshMusic);
Hooks.on("updatePlaylistSound", refreshMusic);
Hooks.on("updateWorldTime", foundry.utils.debounce(() => Lobby.updateCalendar(), 100));
Hooks.on("collapseSidebar", () => setTimeout(() => Lobby.rescale(), 350));

Hooks.on("userConnected", (user, connected) => {
  if (Lobby.el && !Lobby.previewData) Lobby.refresh();
  // If the last GM disconnects mid-session, send the table back to the lobby (handled by the first active player).
  if (!connected && user.isGM && !game.users.some((u) => u.isGM && u.active)
      && game.settings.get(MODULE_ID, "autoLobbyOnGMLeave") && Lobby.live) {
    Lobby.forced = true;
    Lobby.refresh();
  }
});

function toggle() {
  if (game.user.isGM) {
    if (Lobby.previewData) return;
    if (Lobby.live) return Lobby.setLive(false);
    // In the lobby: hide it locally first, then start the session on second press.
    if (Lobby.el) return Lobby.setLive(true);
    Lobby.hiddenForMe = false;
    return Lobby.refresh();
  }
  if (Lobby.el) {
    Lobby.forced = false;
    if (!Lobby.live && Lobby.data.options?.playersCanMinimize === false) return;
    Lobby.hiddenForMe = true;
  } else {
    Lobby.forced = true;
    Lobby.hiddenForMe = false;
  }
  Lobby.refresh();
}

/* ---------------------------------------------------------------------- */
/*  Scene controls button (GM)                                             */
/* ---------------------------------------------------------------------- */

Hooks.on("getSceneControlButtons", (controls) => {
  if (!game.user.isGM) return;
  try {
    const tokens = controls.tokens ?? controls.token ?? Object.values(controls)[0];
    if (!tokens?.tools) return;
    tokens.tools.sessionLobby = {
      name: "sessionLobby",
      title: "Session Lobby",
      icon: "fa-solid fa-door-open",
      order: 99,
      button: true,
      visible: true,
      onChange: () => {
        Lobby.hiddenForMe = false;
        Lobby.forced = Lobby.live;
        Lobby.refresh();
      }
    };
  } catch (err) {
    console.warn(`${MODULE_ID} | could not add scene control`, err);
  }
});
