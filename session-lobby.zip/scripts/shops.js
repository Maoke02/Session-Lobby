/**
 * Stylish Shop integration.
 *
 * Talks to Stylish Shop only through its public API (game.modules.get("stylish-shop").api).
 * Stylish Shop's own switch for "players may browse this shop remotely" is a shop's
 * `publicShop` flag, so opening a shop here means turning that on (GM, via updateShopIdentity),
 * and closing it turns it off. We only ever touch shops the GM has toggled in this panel.
 *
 * Optional: while a session is live, opened shops are closed automatically and reopened when
 * the table returns to the lobby — so remote shopping happens between sessions.
 */
import { MODULE_ID } from "./defaults.js";
import { esc } from "./render.js";

const { ApplicationV2, DialogV2 } = foundry.applications.api;
const { randomID, debounce } = foundry.utils;
const SHOP_ID = "stylish-shop";

export const Shops = {
  get api() {
    const mod = game.modules.get(SHOP_ID);
    return mod?.active && mod.api?.getShopDirectory ? mod.api : null;
  },

  get available() { return !!this.api; },

  get cfg() {
    const saved = game.settings.get(MODULE_ID, "shops") ?? {};
    return { enabled: [], managed: [], groups: [], closeDuringSession: true, ...saved };
  },

  async save(patch) {
    await game.settings.set(MODULE_ID, "shops", { ...this.cfg, ...patch });
  },

  /** Every shop this user can see (GM: all; players: currently public ones). */
  directory() {
    try { return this.api?.getShopDirectory() ?? []; } catch (err) { console.error(err); return []; }
  },

  /** Number of shops players can browse right now (for the {shops} token). */
  openCount() {
    return this.directory().filter((s) => s.publicShop).length;
  },

  /** Should this managed shop be public right now? */
  wantsOpen(id, cfg = this.cfg) {
    if (!cfg.enabled.includes(id)) return false;
    if (cfg.closeDuringSession && game.settings.get(MODULE_ID, "sessionLive")) return false;
    return true;
  },

  /** GM: push our open/closed choices into Stylish Shop. Only the elected GM does the writing. */
  async apply() {
    if (!game.user.isGM || !this.api) return;
    if (game.users.activeGM && !game.users.activeGM.isSelf) return;
    const cfg = this.cfg;
    const shops = new Map(this.directory().map((s) => [s.id, s]));
    for (const id of cfg.managed) {
      const s = shops.get(id);
      if (!s) continue;
      const want = this.wantsOpen(id, cfg);
      if (s.publicShop !== want) {
        const res = await this.api.updateShopIdentity(id, { publicShop: want });
        if (res?.ok === false) console.warn(`${MODULE_ID} | couldn't update shop ${id}:`, res.error);
      }
    }
  },

  async setOpen(ids, open) {
    const cfg = this.cfg;
    const enabled = new Set(cfg.enabled), managed = new Set(cfg.managed);
    for (const id of ids) {
      managed.add(id);
      if (open) enabled.add(id); else enabled.delete(id);
    }
    await this.save({ enabled: [...enabled], managed: [...managed] });
    await this.apply();
  },

  /** Open one specific shop (from a lobby button or map waymark linked to a shop actor). */
  async openShop(actor) {
    const api = this.api;
    if (!api) return ui.notifications.warn("Stylish Shop isn't active in this world.");
    if (!game.user.isGM && !this.directory().some((s) => s.id === actor.id)) {
      return ui.notifications.info(`${actor.name} is closed right now.`);
    }
    const app = api.openShopWithBuyerSelection(actor.id);
    if (!app) ui.notifications.warn(`Couldn't open ${actor.name}. Make sure it's set up as a Stylish Shop.`);
    return app;
  }
};

/* ====================================================================== */

export class ShopsApp extends ApplicationV2 {
  static #instance = null;

  static open() {
    if (!Shops.available) return ui.notifications.warn("Stylish Shop isn't active in this world.");
    this.#instance ??= new ShopsApp();
    this.#instance.render(true);
    setTimeout(() => this.#instance?.bringToFront?.(), 50);
    return this.#instance;
  }

  static get instance() { return this.#instance; }
  static refresh = debounce(() => { if (ShopsApp.#instance?.rendered) ShopsApp.#instance.render(); }, 150);

  static DEFAULT_OPTIONS = {
    id: "session-lobby-shops",
    classes: ["sl-vault-app", "sl-shops-app"],
    tag: "div",
    window: { title: "Shops", icon: "fa-solid fa-store", resizable: true },
    position: { width: 560, height: 680 },
    actions: {
      shopsOpenShop: ShopsApp.#onOpenShop,
      shopsToggle: ShopsApp.#onToggle,
      shopsGroupToggle: ShopsApp.#onGroupToggle,
      shopsAddGroup: ShopsApp.#onAddGroup,
      shopsRenameGroup: ShopsApp.#onRenameGroup,
      shopsDeleteGroup: ShopsApp.#onDeleteGroup,
      shopsAllClosed: ShopsApp.#onAllClosed
    }
  };

  async _renderHTML() {
    return game.user.isGM ? this.#renderGM() : this.#renderPlayer();
  }

  _replaceHTML(result, content) {
    content.innerHTML = result;
    for (const sel of content.querySelectorAll("[data-shop-group]")) {
      sel.addEventListener("change", (ev) => this.#assignGroup(sel.dataset.shopGroup, ev.target.value));
    }
    content.querySelector("[data-shops-auto]")?.addEventListener("change", async (ev) => {
      await Shops.save({ closeDuringSession: ev.target.checked });
      await Shops.apply();
      this.render();
    });
  }

  #shopCard(s, { gm = false, cfg } = {}) {
    const open = s.publicShop;
    const groupOptions = gm ? [`<option value="">— no town —</option>`, ...cfg.groups.map((g) =>
      `<option value="${esc(g.id)}" ${g.shopIds.includes(s.id) ? "selected" : ""}>${esc(g.name)}</option>`)].join("") : "";
    const waiting = gm && cfg.enabled.includes(s.id) && !open && cfg.closeDuringSession && game.settings.get(MODULE_ID, "sessionLive");
    return `<li class="sls-shop${open ? " open" : ""}">
      <img src="${esc(s.img)}" alt="">
      <div class="sls-info">
        <b>${esc(s.name)}</b>
        <small>${esc([s.owner, s.subtitle].filter(Boolean).join(" · ") || `${s.itemCount} items`)}</small>
        ${s.sale?.active ? `<span class="sls-sale">${s.sale.percent ? `${esc(s.sale.percent)}% off` : "Sale"}</span>` : ""}
        ${gm ? `<select data-shop-group="${esc(s.id)}" title="Town">${groupOptions}</select>` : ""}
      </div>
      ${gm ? `<button type="button" class="sls-toggle ${open || waiting ? "on" : ""}" data-action="shopsToggle" data-shop="${esc(s.id)}"
          data-tooltip="${waiting ? "Opens again when you return to the lobby" : open ? "Open — click to close" : "Closed — click to open"}">
          <i class="fa-solid ${open ? "fa-door-open" : waiting ? "fa-hourglass-half" : "fa-door-closed"}"></i> ${open ? "Open" : waiting ? "Waiting" : "Closed"}</button>` : ""}
      <button type="button" data-action="shopsOpenShop" data-shop="${esc(s.id)}"><i class="fa-solid fa-store"></i> ${gm ? "View" : "Enter"}</button>
    </li>`;
  }

  #renderPlayer() {
    const shops = Shops.directory().filter((s) => s.publicShop);
    const cfg = Shops.cfg;
    const gmOnline = !!(game.users.activeGM ?? game.users.find((u) => u.isGM && u.active));
    const grouped = cfg.groups.map((g) => ({ g, list: shops.filter((s) => g.shopIds.includes(s.id)) })).filter((x) => x.list.length);
    const loose = shops.filter((s) => !cfg.groups.some((g) => g.shopIds.includes(s.id)));
    return `<div class="slv sls">
      <header class="slv-head"><div><h2>Shops</h2><small>${shops.length ? `${shops.length} open for business` : "Nothing open right now"}</small></div></header>
      ${!gmOnline && shops.length ? `<div class="slv-status lobby"><i class="fa-solid fa-moon"></i><span>The GM is offline — you can browse, but purchases are approved by the GM and won't go through until they're back.</span></div>` : ""}
      ${shops.length ? [...grouped.map(({ g, list }) => `<h3>${esc(g.name)}</h3><ul class="sls-list">${list.map((s) => this.#shopCard(s)).join("")}</ul>`),
        loose.length ? `${grouped.length ? "<h3>Elsewhere</h3>" : ""}<ul class="sls-list">${loose.map((s) => this.#shopCard(s)).join("")}</ul>` : ""].join("")
      : `<div class="slv-setup"><i class="fa-solid fa-store-slash"></i><p>No shops are open right now. The GM opens them when you're somewhere with merchants.</p></div>`}
    </div>`;
  }

  #renderGM() {
    const cfg = Shops.cfg;
    const shops = Shops.directory().sort((a, b) => a.name.localeCompare(b.name));
    const live = game.settings.get(MODULE_ID, "sessionLive");
    const inGroup = new Set(cfg.groups.flatMap((g) => g.shopIds));
    const loose = shops.filter((s) => !inGroup.has(s.id));
    const groupBlock = (g) => {
      const list = shops.filter((s) => g.shopIds.includes(s.id));
      const anyOpen = list.some((s) => cfg.enabled.includes(s.id));
      return `<section class="sls-town">
        <div class="sls-town-head">
          <h3>${esc(g.name)}</h3>
          <button type="button" data-action="shopsGroupToggle" data-group="${esc(g.id)}" data-open="${anyOpen ? 0 : 1}" ${list.length ? "" : "disabled"}>
            <i class="fa-solid ${anyOpen ? "fa-door-closed" : "fa-door-open"}"></i> ${anyOpen ? "Close town" : "Open town"}</button>
          <button type="button" class="slv-x" data-action="shopsRenameGroup" data-group="${esc(g.id)}" data-tooltip="Rename"><i class="fa-solid fa-pen"></i></button>
          <button type="button" class="slv-x" data-action="shopsDeleteGroup" data-group="${esc(g.id)}" data-tooltip="Delete town (shops stay)"><i class="fa-solid fa-trash"></i></button>
        </div>
        <ul class="sls-list">${list.map((s) => this.#shopCard(s, { gm: true, cfg })).join("") || `<li class="slv-empty">Use a shop's town menu to put it here.</li>`}</ul>
      </section>`;
    };
    return `<div class="slv sls">
      <header class="slv-head"><div><h2>Shops</h2><small>${shops.filter((s) => s.publicShop).length} of ${shops.length} open to players</small></div></header>
      <div class="slv-status gm"><i class="fa-solid fa-crown"></i><span>Open shops can be browsed by players from the lobby (and Stylish Shop's own Shop Directory). Purchases still come to you for approval.</span></div>
      <label class="sls-auto"><input type="checkbox" data-shops-auto ${cfg.closeDuringSession ? "checked" : ""}>
        Close open shops while a session is live, and reopen them when you return to the lobby${live && cfg.closeDuringSession ? " <em>(session is live — open shops are waiting)</em>" : ""}</label>
      ${shops.length ? "" : `<div class="slv-setup"><i class="fa-solid fa-store"></i><p>No Stylish Shops found. Create a shop with Stylish Shop first.</p></div>`}
      ${cfg.groups.map(groupBlock).join("")}
      ${loose.length ? `<section class="sls-town"><div class="sls-town-head"><h3>${cfg.groups.length ? "Not in a town" : "All shops"}</h3></div>
        <ul class="sls-list">${loose.map((s) => this.#shopCard(s, { gm: true, cfg })).join("")}</ul></section>` : ""}
      <div class="slv-buttons">
        <button type="button" data-action="shopsAddGroup"><i class="fa-solid fa-city"></i> New town</button>
        <button type="button" data-action="shopsAllClosed"><i class="fa-solid fa-door-closed"></i> Close every shop</button>
      </div>
    </div>`;
  }

  async #assignGroup(shopId, groupId) {
    const groups = Shops.cfg.groups.map((g) => ({ ...g, shopIds: g.shopIds.filter((id) => id !== shopId) }));
    const target = groups.find((g) => g.id === groupId);
    if (target) target.shopIds.push(shopId);
    await Shops.save({ groups });
    this.render();
  }

  /* actions (this = app) */

  static async #onOpenShop(ev, target) {
    const actor = game.actors.get(target.dataset.shop);
    if (actor) await Shops.openShop(actor);
  }

  static async #onToggle(ev, target) {
    const id = target.dataset.shop;
    const enabled = Shops.cfg.enabled.includes(id);
    await Shops.setOpen([id], !enabled);
    this.render();
  }

  static async #onGroupToggle(ev, target) {
    const g = Shops.cfg.groups.find((x) => x.id === target.dataset.group);
    if (!g) return;
    await Shops.setOpen(g.shopIds, target.dataset.open === "1");
    ui.notifications.info(`${g.name}: shops ${target.dataset.open === "1" ? "opened" : "closed"}.`);
    this.render();
  }

  static async #onAddGroup() {
    const name = await this.#askName("New town", "");
    if (!name) return;
    await Shops.save({ groups: [...Shops.cfg.groups, { id: randomID(), name, shopIds: [] }] });
    this.render();
  }

  static async #onRenameGroup(ev, target) {
    const groups = Shops.cfg.groups;
    const g = groups.find((x) => x.id === target.dataset.group);
    const name = g && await this.#askName("Rename town", g.name);
    if (!name) return;
    g.name = name;
    await Shops.save({ groups });
    this.render();
  }

  static async #onDeleteGroup(ev, target) {
    const g = Shops.cfg.groups.find((x) => x.id === target.dataset.group);
    if (!g) return;
    const ok = await DialogV2.confirm({ window: { title: "Delete town" }, content: `<p>Delete the town <b>${esc(g.name)}</b>? Its shops are kept.</p>` });
    if (!ok) return;
    await Shops.save({ groups: Shops.cfg.groups.filter((x) => x.id !== g.id) });
    this.render();
  }

  static async #onAllClosed() {
    await Shops.setOpen(Shops.directory().map((s) => s.id), false);
    ui.notifications.info("All shops closed to players.");
    this.render();
  }

  async #askName(title, value) {
    const name = await DialogV2.prompt({
      window: { title },
      content: `<input type="text" name="name" value="${esc(value)}" placeholder="e.g. Thistledown" autofocus style="width:100%">`,
      ok: { label: "Save", callback: (event, button) => button.form.elements.name.value.trim() }
    }).catch(() => null);
    return name || null;
  }
}

/* ====================================================================== */

export function registerShops() {
  game.settings.register(MODULE_ID, "shops", {
    scope: "world", config: false, type: Object,
    default: { enabled: [], managed: [], groups: [], closeDuringSession: true },
    onChange: () => ShopsApp.refresh()
  });
  game.keybindings.register(MODULE_ID, "openShops", {
    name: "Open the Shops list (Stylish Shop)",
    editable: [],
    onDown: () => { ShopsApp.open(); return true; }
  });
  // Shop changes made in Stylish Shop itself (or by another GM) refresh our window.
  Hooks.on("stylishShop.shopUpdated", () => ShopsApp.refresh());
  Hooks.on("updateActor", (actor, change) => {
    if (change?.flags?.[SHOP_ID] || "name" in (change ?? {})) ShopsApp.refresh();
  });
}

/** When the session starts or ends, close/reopen shops (GM side). */
export function onSessionLiveChanged() {
  Shops.apply();
  ShopsApp.refresh();
}
