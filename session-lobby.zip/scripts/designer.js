import { MODULE_ID, ACTION_TYPES, TEMPLATES, blankAction, defaultLayout, grimoireLayout, defaultsFor } from "./defaults.js";
import { esc } from "./render.js";
import { RELATIONSHIP_VIEWS } from "./integrations.js";
import { Lobby } from "./lobby.js";

const { ApplicationV2, DialogV2 } = foundry.applications.api;
const { deepClone, getProperty, setProperty, mergeObject, randomID } = foundry.utils;

const TABS = {
  header: "Header",
  hero: "Hero",
  buttons: "Buttons & Cards",
  party: "Party & Quotes",
  widgets: "Clock & Music",
  look: "Look"
};

const GR_TABS = {
  banner: "Banner & Nav",
  hero: "Hero",
  party: "Party",
  cards: "Cards & Links",
  time: "Calendar & Music",
  look: "Look"
};

const NEW_ITEMS = {
  slide: () => ({ src: "", scale: 100, offsetX: 0, offsetY: 0 }),
  link: () => ({ icon: "fa-solid fa-star", label: "New link", action: blankAction("journal") }),
  navItem: () => ({ icon: "fa-solid fa-star", label: "New", active: false, action: blankAction("journal") }),
  grCard: () => ({ label: "NEW", icon: "fa-solid fa-star", title: "New card", sub: "Subtitle", image: "", action: blankAction("journal") }),
  grCast: () => ({ name: "New Hero", sub: "Lv 1 · Adventurer", image: "", userId: "", action: blankAction("actor") }),
  chips: () => ({ icon: "fa-solid fa-star", text: "NEW CHIP", style: "plain" }),
  buttons: () => ({ icon: "fa-solid fa-star", label: "NEW", sub: "BUTTON", action: blankAction("text") }),
  cards: () => ({ icon: "fa-solid fa-star", title: "NEW CARD", sub: "SUBTITLE", badge: "", accent: false, action: blankAction("text") }),
  cast: () => ({ name: "New Hero", image: "", userId: "", highlight: false, action: blankAction("actor") }),
  quotes: () => ({ speaker: "Someone", role: "ROLE", text: "Say something memorable." })
};

const DOC_TO_ACTION = {
  JournalEntry: "journal", JournalEntryPage: "journal", Actor: "actor",
  Item: "item", Macro: "macro", Scene: "scene"
};

/** In-game editor for lobby layouts, with live preview. */
export class LobbyDesigner extends ApplicationV2 {
  static #instance = null;

  static open() {
    if (!game.user.isGM) return ui.notifications.warn("Only the GM can design the lobby.");
    this.#instance ??= new LobbyDesigner();
    this.#instance.render(true);
    return this.#instance;
  }

  constructor(options = {}) {
    super(options);
    this.#loadStore();
    this.tab = "header";
  }

  static DEFAULT_OPTIONS = {
    id: "session-lobby-designer",
    classes: ["sl-designer"],
    tag: "div",
    window: { title: "Lobby Designer", icon: "fa-solid fa-pen-ruler", resizable: true },
    position: { width: 720, height: 820, left: 60, top: 60 },
    actions: {
      slTab: LobbyDesigner.#onTab,
      addItem: LobbyDesigner.#onAddItem,
      removeItem: LobbyDesigner.#onRemoveItem,
      moveItem: LobbyDesigner.#onMoveItem,
      pickFile: LobbyDesigner.#onPickFile,
      addSlideFolder: LobbyDesigner.#onAddSlideFolder,
      save: LobbyDesigner.#onSave,
      revert: LobbyDesigner.#onRevert,
      newLayout: LobbyDesigner.#onNewLayout,
      dupLayout: LobbyDesigner.#onDupLayout,
      delLayout: LobbyDesigner.#onDelLayout,
      makeActive: LobbyDesigner.#onMakeActive,
      exportJson: LobbyDesigner.#onExport,
      importJson: LobbyDesigner.#onImport,
      testAction: LobbyDesigner.#onTestAction
    }
  };

  #loadStore() {
    this.store = deepClone(game.settings.get(MODULE_ID, "store"));
    this.store.layouts ??= {};
    for (const [id, l] of Object.entries(this.store.layouts)) {
      this.store.layouts[id] = mergeObject(defaultsFor(l.template), l, { inplace: false });
    }
    for (const l of Object.values(this.store.layouts)) {
      const bg = l.background ?? {};
      if (bg.art && !(bg.slides ?? []).length) bg.slides = [{ src: bg.art, scale: 100, offsetX: 0, offsetY: 0 }];
      if ((bg.slides ?? []).length) bg.art = "";
    }
    if (!Object.keys(this.store.layouts).length) this.store.layouts.main = defaultLayout();
    if (!this.store.layouts[this.store.active]) this.store.active = Object.keys(this.store.layouts)[0];
    this.editing = this.store.active;
    this.dirty = false;
  }

  get layout() {
    return this.store.layouts[this.editing];
  }

  get tabs() {
    return this.layout?.template === "grimoire" ? GR_TABS : TABS;
  }

  /* ------------------------------------------------------------------ */
  /*  Rendering                                                           */
  /* ------------------------------------------------------------------ */

  async _renderHTML() {
    const L = this.layout;
    const layoutOptions = Object.entries(this.store.layouts).map(([id, l]) =>
      `<option value="${esc(id)}" ${id === this.editing ? "selected" : ""}>${esc(l.name || id)}${id === this.store.active ? "  ★ active" : ""}</option>`).join("");

    if (!(this.tab in this.tabs)) this.tab = Object.keys(this.tabs)[0];
    const tabs = Object.entries(this.tabs).map(([k, v]) =>
      `<a data-action="slTab" data-sl-tab="${k}" class="${k === this.tab ? "active" : ""}">${v}</a>`).join("");

    return `<form class="sl-dz" autocomplete="off">
      <div class="sl-dz-top">
        <select data-layout-select title="Layout you are editing">${layoutOptions}</select>
        <span class="sl-theme-tag" title="Theme">${esc(TEMPLATES[L.template] ?? L.template)}</span>
        <button type="button" data-action="makeActive" title="Show this layout to players"><i class="fa-solid fa-star"></i></button>
        <button type="button" data-action="newLayout" title="New layout"><i class="fa-solid fa-plus"></i></button>
        <button type="button" data-action="dupLayout" title="Duplicate"><i class="fa-solid fa-copy"></i></button>
        <button type="button" data-action="delLayout" title="Delete"><i class="fa-solid fa-trash"></i></button>
        <button type="button" data-action="exportJson" title="Export JSON"><i class="fa-solid fa-file-export"></i></button>
        <button type="button" data-action="importJson" title="Import JSON"><i class="fa-solid fa-file-import"></i></button>
      </div>
      <nav class="sl-dz-tabs">${tabs}</nav>
      <div class="sl-dz-body">${this.#tabBody(L)}</div>
      <div class="sl-dz-foot">
        <button type="button" data-action="revert"><i class="fa-solid fa-rotate-left"></i> Revert</button>
        <button type="button" data-action="save"><i class="fa-solid fa-floppy-disk"></i> Save${this.dirty ? " *" : ""}</button>
      </div>
    </form>`;
  }

  _replaceHTML(result, content) {
    const scroll = content.querySelector(".sl-dz-body")?.scrollTop ?? 0;
    content.innerHTML = result;
    const body = content.querySelector(".sl-dz-body");
    if (body) body.scrollTop = scroll;
    this.#bind(content);
  }

  _onFirstRender(...args) {
    super._onFirstRender?.(...args);
    Lobby.preview(this.layout);
  }

  async close(options) {
    if (this.dirty) {
      const ok = await DialogV2.confirm({
        window: { title: "Unsaved changes" },
        content: "<p>Close the designer and discard unsaved changes?</p>"
      });
      if (!ok) return this;
    }
    Lobby.endPreview();
    LobbyDesigner.#instance = null;
    return super.close(options);
  }

  /* ------------------------------------------------------------------ */
  /*  Field builders                                                      */
  /* ------------------------------------------------------------------ */

  #v(path) { return getProperty(this.layout, path) ?? ""; }

  #group(label, inner, hint = "") {
    return `<div class="form-group"><label>${label}</label>${inner}</div>${hint ? `<p class="hint">${hint}</p>` : ""}`;
  }
  #text(path, label, hint) {
    return this.#group(label, `<input type="text" name="${path}" value="${esc(this.#v(path))}">`, hint);
  }
  #area(path, label, hint, tall = false) {
    return this.#group(label, `<textarea name="${path}" class="${tall ? "tall" : ""}">${esc(this.#v(path))}</textarea>`, hint);
  }
  #num(path, label, step = 1, hint) {
    return this.#group(label, `<input type="number" step="${step}" name="${path}" value="${esc(this.#v(path))}">`, hint);
  }
  #check(path, label, hint) {
    return this.#group(label, `<input type="checkbox" name="${path}" ${this.#v(path) ? "checked" : ""}>`, hint);
  }
  #select(path, label, options, rerender = false) {
    const cur = this.#v(path);
    const opts = Object.entries(options).map(([k, v]) => `<option value="${esc(k)}" ${k === cur ? "selected" : ""}>${esc(v)}</option>`).join("");
    return this.#group(label, `<select name="${path}" ${rerender ? "data-rerender" : ""}>${opts}</select>`);
  }
  #color(path, label) {
    const v = String(this.#v(path));
    const hex = /^#[0-9a-f]{6}$/i.test(v) ? v : "#ffffff";
    return this.#group(label, `<div class="sl-color"><input type="color" value="${hex}" data-color-for="${path}"><input type="text" name="${path}" value="${esc(v)}"></div>`);
  }
  #file(path, label, hint) {
    return this.#group(label, `<div class="sl-row"><input type="text" name="${path}" value="${esc(this.#v(path))}" placeholder="path/to/file.webp">
      <button type="button" data-action="pickFile" data-target="${path}" title="Browse"><i class="fa-solid fa-file-image"></i></button></div>`, hint);
  }
  #icon(path, label = "Icon") {
    return this.#group(label, `<div class="sl-row"><input type="text" name="${path}" value="${esc(this.#v(path))}" placeholder="fa-solid fa-star"><span style="width:26px;text-align:center"><i class="${esc(this.#v(path))}"></i></span></div>`);
  }
  #datetime(path, label, hint) {
    return this.#group(label, `<input type="datetime-local" name="${path}" value="${esc(this.#v(path))}">`, hint);
  }

  #action(path) {
    const a = this.#v(path) || {};
    const type = a.type || "none";
    let inner = this.#select(`${path}.type`, "On click", ACTION_TYPES, true);
    if (["journal", "actor", "item", "macro", "scene", "shop"].includes(type)) {
      inner += this.#group("Linked document", `<div class="sl-row"><input type="text" name="${path}.uuid" value="${esc(a.uuid)}" data-drop="${path}" placeholder="Drag a ${type} here (or paste its UUID)">
        <button type="button" data-action="testAction" data-path="${path}" title="Test"><i class="fa-solid fa-play"></i></button></div>`);
    }
    if (type === "relationships") {
      inner += this.#select(`${path}.view`, "Opens", RELATIONSHIP_VIEWS, true);
      if (a.view === "actor") inner += this.#group("Character", `<input type="text" name="${path}.uuid" value="${esc(a.uuid)}" data-drop="${path}" placeholder="Drag an Actor here">`);
    }
    if (type === "url") inner += this.#text(`${path}.url`, "Web address");
    if (type === "text") {
      inner += this.#text(`${path}.title`, "Pop-up title");
      inner += this.#area(`${path}.content`, "Pop-up text", "HTML and Foundry links (@UUID[…]) work here.", true);
    }
    return `<div class="sl-action" data-drop="${path}">${inner}</div>`;
  }

  /** A reorderable list of sub-items. */
  #list(listPath, kind, title, renderItem) {
    const items = this.#v(listPath) || [];
    const rows = items.map((item, i) => `
      <div class="sl-item">
        <div class="sl-item-head"><span>${esc(title(item, i))}</span>
          <button type="button" data-action="moveItem" data-path="${listPath}" data-index="${i}" data-dir="-1" title="Up"><i class="fa-solid fa-arrow-up"></i></button>
          <button type="button" data-action="moveItem" data-path="${listPath}" data-index="${i}" data-dir="1" title="Down"><i class="fa-solid fa-arrow-down"></i></button>
          <button type="button" data-action="removeItem" data-path="${listPath}" data-index="${i}" title="Remove"><i class="fa-solid fa-xmark"></i></button>
        </div>
        ${renderItem(`${listPath}.${i}`, item, i)}
      </div>`).join("");
    return `${rows}<button type="button" data-action="addItem" data-path="${listPath}" data-kind="${kind}"><i class="fa-solid fa-plus"></i> Add</button>`;
  }

  #tabBody(L) {
    if (L.template === "grimoire") return this.#grimoireBody(L);
    const users = { "": "— not linked —" };
    for (const u of game.users) if (!u.isGM) users[u.id] = u.name;
    const tokensHint = "Tokens: {date} {longDate} {time} {countdown} {dday} {nextDate} {online} {total} {world} {music}";

    switch (this.tab) {
      case "header": return `
        ${this.#text("name", "Layout name (GM only)")}
        <h3>Logo &amp; title</h3>
        ${this.#file("brand.logo", "Logo image", "Leave empty to use the icon below.")}
        ${this.#icon("brand.icon", "Logo icon")}
        ${this.#text("brand.title", "Title")}
        ${this.#text("brand.subtitle", "Subtitle")}
        ${this.#text("brand.meta1", "Meta line 1", tokensHint)}
        ${this.#text("brand.meta2", "Meta line 2")}
        ${this.#text("brand.badge", "Badge")}
        ${this.#text("brand.badgeText", "Badge text")}
        <h3>Edges</h3>
        ${this.#text("sideText", "Vertical side text")}
        ${this.#text("footer.left", "Footer left")}
        ${this.#text("footer.right", "Footer right")}`;

      case "hero": return `
        ${this.#text("hero.number", "Section number")}
        ${this.#text("hero.label", "Section label")}
        ${this.#text("hero.tag", "Tag")}
        ${this.#text("hero.line1", "Headline line 1")}
        ${this.#text("hero.line2", "Headline line 2 (highlighted)")}
        ${this.#area("hero.tagline", "Tagline", "One line per row. " + tokensHint)}
        <h3>Chips</h3>
        ${this.#list("hero.chips", "chips", (c) => c.text || "Chip", (p) => `
          ${this.#icon(`${p}.icon`)}${this.#text(`${p}.text`, "Text")}
          ${this.#select(`${p}.style`, "Style", { plain: "Plain", accent: "Accent" })}`)}`;

      case "buttons": return `
        <h3>Big button</h3>
        ${this.#text("cta.small", "Small text")}
        ${this.#text("cta.label", "Label", "Clear the label to hide the big button.")}
        ${this.#icon("cta.icon")}
        ${this.#action("cta.action")}
        <h3>Small buttons</h3>
        ${this.#list("buttons", "buttons", (b) => b.label || "Button", (p) => `
          ${this.#icon(`${p}.icon`)}${this.#text(`${p}.label`, "Label")}${this.#text(`${p}.sub`, "Sub-label")}
          ${this.#action(`${p}.action`)}`)}
        <h3>Bottom cards</h3>
        <p class="hint">${tokensHint}</p>
        ${this.#list("cards", "cards", (c) => c.title || "Card", (p) => `
          ${this.#icon(`${p}.icon`)}${this.#text(`${p}.title`, "Title")}${this.#text(`${p}.sub`, "Subtitle")}
          ${this.#text(`${p}.badge`, "Badge")}${this.#check(`${p}.accent`, "Accent badge")}
          ${this.#action(`${p}.action`)}`)}`;

      case "party": return `
        <h3>Polaroids</h3>
        ${this.#text("cast.title", "Column title")}
        ${this.#check("cast.showCount", "Show count")}
        <p class="hint">Tip: drag an Actor onto a polaroid's "Linked document" box — the name and portrait fill in automatically.</p>
        ${this.#list("cast.items", "cast", (c) => c.name || "Character", (p) => `
          ${this.#text(`${p}.name`, "Name")}${this.#file(`${p}.image`, "Portrait")}
          ${this.#select(`${p}.userId`, "Player (online dot)", users)}
          ${this.#check(`${p}.highlight`, "Highlight")}
          ${this.#action(`${p}.action`)}`)}
        <h3>Quote bubble</h3>
        ${this.#check("quotes.show", "Show quotes")}
        ${this.#num("quotes.interval", "Seconds per quote")}
        ${this.#list("quotes.items", "quotes", (q) => q.speaker || "Quote", (p) => `
          ${this.#text(`${p}.speaker`, "Speaker")}${this.#text(`${p}.role`, "Role")}${this.#area(`${p}.text`, "Quote")}`)}`;

      case "widgets": return `
        <h3>Clock card</h3>
        ${this.#check("clock.show", "Show clock card")}
        ${this.#text("clock.weatherIcon", "Weather icon (emoji)")}
        ${this.#text("clock.weather", "Weather text")}
        ${this.#text("clock.countdownLabel", "Countdown label")}
        ${this.#datetime("clock.nextSession", "Next session", "Drives {countdown}, {dday} and {nextDate}.")}
        ${this.#text("clock.presentLabel", "Attendance label")}
        ${this.#check("clock.use24h", "24-hour clock")}
        <h3>Now playing</h3>
        ${this.#check("topBar.show", "Show music bar")}
        ${this.#check("options.showMusic", "Show current playlist track")}
        ${this.#text("topBar.idleText", "Text when silent")}
        ${this.#text("topBar.label", "Label")}
        ${this.#text("topBar.sub1", "Line below")}
        ${this.#text("topBar.sub2", "Line below (accent)")}
        <h3>Players</h3>
        ${this.#check("options.playersCanMinimize", "Players can minimize the lobby")}
        ${this.#check("options.showSidebar", "Keep the chat sidebar visible", "Lets everyone chat while waiting in the lobby.")}`;

      case "look": return `
        <h3>Colors</h3>
        ${this.#color("theme.primary", "Primary (ink)")}
        ${this.#color("theme.accent", "Accent (highlighter)")}
        ${this.#color("theme.text", "Body text")}
        ${this.#color("theme.muted", "Muted text")}
        ${this.#color("theme.panel", "Panel background")}
        ${this.#check("theme.ruled", "Notebook lines")}
        <h3>Fonts</h3>
        <p class="hint">Any font Foundry knows — add your own under Core Settings → Additional Fonts.</p>
        ${this.#text("theme.headlineFont", "Headline font")}
        ${this.#text("theme.displayFont", "Display font")}
        ${this.#text("theme.bodyFont", "Body font")}
        <h3>Background</h3>
        ${this.#file("background.image", "Background", "Image or video (webm/mp4). Empty = painted sky.")}
        ${this.#color("background.tint", "Tint overlay")}
        ${this.#artSection()}`;
    }
    return "";
  }

  #grimoireBody(L) {
    const users = { "": "— not linked —" };
    for (const u of game.users) if (!u.isGM) users[u.id] = u.name;
    const tokensHint = "Tokens: {calDate} {calDay} {calMonth} {calYear} {calWeekday} {calTime} {season} {dday} {nextDate} {countdown} {online} {total} {world}";
    const linkItem = (p) => `${this.#icon(`${p}.icon`)}${this.#text(`${p}.label`, "Label")}${this.#action(`${p}.action`)}`;

    switch (this.tab) {
      case "banner": return `
        ${this.#text("name", "Layout name (GM only)")}
        <h3>Side banner</h3>
        ${this.#check("banner.show", "Show banner")}
        ${this.#file("banner.crest", "Crest image", "Leave empty for the built-in compass.")}
        ${this.#text("banner.line1", "Title line 1")}
        ${this.#text("banner.line2", "Small middle line")}
        ${this.#text("banner.line3", "Title line 2")}
        ${this.#file("banner.image", "Bottom image", "Shown at the pointed bottom of the banner.")}
        <h3>Banner links</h3>
        ${this.#list("banner.links", "link", (l) => l.label || "Link", linkItem)}
        <h3>Top navigation</h3>
        ${this.#check("nav.show", "Show top bar")}
        ${this.#list("nav.items", "navItem", (l) => l.label || "Item", (p) => `${linkItem(p)}${this.#check(`${p}.active`, "Highlighted")}`)}`;

      case "hero": return `
        <p class="hint">${tokensHint}</p>
        ${this.#text("hero.eyebrow", "Small heading")}
        ${this.#text("hero.line1", "Headline line 1")}
        ${this.#text("hero.line2", "Headline line 2")}
        ${this.#area("hero.tagline", "Tagline", "One line per row.")}
        ${this.#text("hero.buttonLabel", "Button label", "Clear it to hide the button.")}
        ${this.#action("hero.buttonAction")}
        ${this.#datetime("clock.nextSession", "Next real-world session", "Drives {dday}, {nextDate} and {countdown}.")}`;

      case "party": return `
        ${this.#text("cast.title", "Panel title")}
        ${this.#check("cast.showCount", "Show count")}
        <p class="hint">Drag an Actor onto a member's "Linked document" box — name, portrait and level/class fill in automatically.</p>
        ${this.#list("cast.items", "grCast", (c) => c.name || "Member", (p) => `
          ${this.#text(`${p}.name`, "Name")}${this.#text(`${p}.sub`, "Subtitle")}${this.#file(`${p}.image`, "Portrait")}
          ${this.#select(`${p}.userId`, "Player (online dot)", users)}
          ${this.#action(`${p}.action`)}`)}`;

      case "cards": return `
        <h3>Feature cards</h3>
        <p class="hint">Current arc, recent session, upcoming… add as many as you like. ${tokensHint}</p>
        ${this.#list("cards", "grCard", (c) => c.label || "Card", (p) => `
          ${this.#file(`${p}.image`, "Card image")}
          ${this.#text(`${p}.label`, "Tag")}${this.#icon(`${p}.icon`, "Tag icon")}
          ${this.#text(`${p}.title`, "Title")}${this.#text(`${p}.sub`, "Subtitle")}
          ${this.#action(`${p}.action`)}`)}
        <h3>Quick links</h3>
        ${this.#text("links.title", "Panel title")}
        ${this.#list("links.items", "link", (l) => l.label || "Link", linkItem)}`;

      case "time": {
        const src = L.calendar?.source;
        return `
        <h3>In-game calendar</h3>
        ${this.#check("calendar.show", "Show calendar")}
        ${this.#select("calendar.source", "Date comes from", {
          core: "Foundry's calendar (world time — e.g. dnd5e Harptos)",
          worldTime: "My own months, driven by world time",
          manual: "I type the date myself"
        }, true)}
        ${src === "core" ? `
          <p class="hint">Uses the calendar your system/world is set to. If it looks off by one, nudge it here.</p>
          ${this.#num("calendar.dayOffset", "Day adjust")}
          ${this.#num("calendar.yearAdjust", "Year adjust")}` : `
          ${this.#area("calendar.months", "Months", "One per line as Name: days (e.g. Hammer: 30).", true)}
          ${this.#area("calendar.weekdays", "Weekdays", "Comma separated, in order.")}`}
        ${src === "worldTime" ? `
          ${this.#num("calendar.yearOffset", "Year at world time 0")}
          ${this.#num("calendar.startOffsetDays", "Start offset (days)", 1, "Shift the starting day without touching world time.")}` : ""}
        ${src === "manual" ? `
          <div class="form-group"><label>Date</label><div class="sl-row">
            <input type="number" name="calendar.manual.day" value="${esc(this.#v("calendar.manual.day"))}" title="Day" placeholder="Day">
            <select name="calendar.manual.month" title="Month">${this.#monthOptions(L)}</select>
            <input type="number" name="calendar.manual.year" value="${esc(this.#v("calendar.manual.year"))}" title="Year" placeholder="Year">
          </div></div>
          <div class="form-group"><label>Time</label><div class="sl-row">
            <input type="number" min="0" max="23" name="calendar.manual.hour" value="${esc(this.#v("calendar.manual.hour"))}" title="Hour">
            <span>:</span>
            <input type="number" min="0" max="59" name="calendar.manual.minute" value="${esc(this.#v("calendar.manual.minute"))}" title="Minute">
          </div></div>
          ${this.#num("calendar.yearOffset", "First year of the calendar")}` : ""}
        ${this.#text("calendar.era", "Era (e.g. DR)")}
        ${this.#text("calendar.season", "Season text", src === "core" ? "Leave empty to use the calendar's own season." : "")}
        ${this.#text("calendar.moon", "Moon / extra text")}
        ${this.#check("calendar.showTime", "Show time of day")}
        ${src !== "manual" ? this.#check("calendar.gmControls", "GM time buttons in the calendar pop-up") : ""}
        <h3>Music player</h3>
        ${this.#check("music.show", "Show music player")}
        ${this.#text("music.title", "Label")}
        ${this.#file("music.cover", "Cover art")}
        ${this.#text("music.idleText", "Text when silent")}
        ${this.#group("Play button starts", `<input type="text" name="music.playlistUuid" value="${esc(this.#v("music.playlistUuid"))}" data-drop="music.playlistUuid" placeholder="Drag a Playlist here">`, "Otherwise the first playlist is used.")}
        ${this.#check("music.showVolume", "Volume slider (each player's own volume)")}
        <h3>Players</h3>
        ${this.#check("options.playersCanMinimize", "Players can minimize the lobby")}
        ${this.#check("options.showSidebar", "Keep the chat sidebar visible")}`;
      }

      case "look": return `
        <h3>Colors</h3>
        ${this.#color("theme.navy", "Banner / dark")}
        ${this.#color("theme.gold", "Gold trim")}
        ${this.#color("theme.parchment", "Parchment")}
        ${this.#color("theme.ink", "Ink")}
        ${this.#color("theme.inkSoft", "Soft ink")}
        ${this.#num("theme.parchmentOpacity", "Parchment opacity", 0.05, "0 = see-through, 1 = solid.")}
        ${this.#file("theme.parchmentTexture", "Parchment texture", "Optional paper image used on every panel.")}
        <h3>Fonts</h3>
        <p class="hint">Any font Foundry knows — add your own under Core Settings → Additional Fonts.</p>
        ${this.#text("theme.headlineFont", "Headline font")}
        ${this.#text("theme.capsFont", "Small-caps font")}
        ${this.#text("theme.bodyFont", "Body font")}
        <h3>Background</h3>
        ${this.#file("background.image", "Background", "Image or video (webm/mp4).")}
        ${this.#color("background.tint", "Tint overlay")}
        ${this.#artSection()}`;
    }
    return "";
  }

  /** Character art: placement + a slideshow of any number of images. */
  #artSection() {
    return `<h3>Character art</h3>
      ${this.#num("background.artX", "Horizontal (%)", 1, "Center of the art, 0–100 across the screen.")}
      ${this.#num("background.artY", "Lift from bottom (%)")}
      ${this.#num("background.artHeight", "Height (%)")}
      ${this.#check("background.artFlip", "Flip horizontally")}
      <h3>Slideshow</h3>
      <p class="hint">Add one image for a still picture, or several to have them fade into each other. Transparent PNG/WebP works best.</p>
      ${this.#num("background.slideSeconds", "Seconds per image", 1)}
      ${this.#num("background.fadeSeconds", "Fade length (seconds)", 0.1)}
      ${this.#check("background.shuffle", "Random order")}
      ${this.#list("background.slides", "slide", (sl, i) => `${i + 1}. ${String(sl.src || "empty").split("/").pop()}`, (p) => `
        ${this.#file(`${p}.src`, "Image")}
        ${this.#num(`${p}.scale`, "Size (%)", 5, "Make a single image bigger or smaller than the others.")}
        ${this.#num(`${p}.offsetX`, "Nudge left/right (%)")}
        ${this.#num(`${p}.offsetY`, "Nudge up/down (%)")}`)}
      <button type="button" data-action="addSlideFolder"><i class="fa-solid fa-folder-plus"></i> Add every image in a folder</button>`;
  }

  #monthOptions(L) {
    const cur = Number(this.#v("calendar.manual.month")) || 1;
    return String(L.calendar?.months || "").split("\n").map((l) => l.trim()).filter(Boolean)
      .map((l, i) => `<option value="${i + 1}" ${i + 1 === cur ? "selected" : ""}>${esc(l.replace(/\s*[:|,]\s*\d+\s*$/, ""))}</option>`).join("");
  }

  /* ------------------------------------------------------------------ */
  /*  Listeners                                                           */
  /* ------------------------------------------------------------------ */

  #bind(root) {
    const form = root.querySelector("form");
    form.addEventListener("submit", (ev) => ev.preventDefault());
    form.addEventListener("input", (ev) => {
      if (ev.target.matches("[data-color-for]")) {
        const target = form.querySelector(`[name="${ev.target.dataset.colorFor}"]`);
        if (target) target.value = ev.target.value;
      }
      this.#collect(form);
      this.#changed();
    });
    form.addEventListener("change", (ev) => {
      this.#collect(form);
      this.#changed();
      if (ev.target.matches("[data-rerender]")) this.render();
    });
    root.querySelector("[data-layout-select]")?.addEventListener("change", (ev) => {
      this.editing = ev.target.value;
      Lobby.preview(this.layout);
      this.render();
    });
    for (const zone of root.querySelectorAll("[data-drop]")) {
      zone.addEventListener("dragover", (ev) => { ev.preventDefault(); zone.classList.add("sl-drop"); });
      zone.addEventListener("dragleave", () => zone.classList.remove("sl-drop"));
      zone.addEventListener("drop", (ev) => this.#onDrop(ev, zone.dataset.drop));
    }
  }

  #collect(form) {
    for (const el of form.querySelectorAll("[name]")) {
      let value = el.value;
      if (el.type === "checkbox") value = el.checked;
      else if (el.type === "number") value = el.value === "" ? 0 : Number(el.value);
      setProperty(this.layout, el.name, value);
    }
  }

  #changed() {
    this.dirty = true;
    const saveBtn = this.element?.querySelector('[data-action="save"]');
    if (saveBtn && !saveBtn.textContent.includes("*")) saveBtn.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> Save *`;
    clearTimeout(this._previewTimer);
    this._previewTimer = setTimeout(() => Lobby.preview(this.layout), 150);
  }

  async #onDrop(ev, actionPath) {
    ev.preventDefault();
    ev.stopPropagation();
    ev.currentTarget.classList.remove("sl-drop");
    let data;
    try { data = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch { return; }
    const uuid = data.uuid ?? (data.type && data.id ? `${data.type}.${data.id}` : null);
    if (!uuid) return;
    const doc = await fromUuid(uuid);
    if (!doc) return;
    this.#collect(this.element.querySelector("form"));
    if (actionPath === "music.playlistUuid") {
      setProperty(this.layout, actionPath, doc.uuid);
      this.#changed();
      return this.render();
    }
    const action = getProperty(this.layout, actionPath);
    action.uuid = doc.uuid;
    if (action.type === "relationships" && doc.documentName === "Actor") action.view = "actor";
    else if (!(action.type === "shop" && doc.documentName === "Actor")) action.type = DOC_TO_ACTION[doc.documentName] ?? action.type;

    // Dropping an actor onto a polaroid fills its name and portrait.
    const itemPath = actionPath.replace(/\.action$/, "");
    if (itemPath.startsWith("cast.items.") && doc.documentName === "Actor") {
      const item = getProperty(this.layout, itemPath);
      if (!item.image || item.image.includes("mystery-man")) item.image = doc.img;
      if (!item.name || /^(New )?Hero|^(Kimi|Kali|Memnok|Poe|Adaine)$/.test(item.name)) item.name = doc.name;
      if ("sub" in item && (!item.sub || /Adventurer$/.test(item.sub))) {
        const lvl = doc.system?.details?.level ?? doc.system?.attributes?.level?.value;
        const classes = (doc.itemTypes?.class ?? []).map((c) => c.name).join(" / ");
        item.sub = [lvl ? `Lv ${lvl}` : "", classes].filter(Boolean).join(" · ") || item.sub;
      }
      const owner = game.users.find((u) => !u.isGM && u.character?.id === doc.id);
      if (owner && !item.userId) item.userId = owner.id;
    }
    this.#changed();
    this.render();
  }

  /* ------------------------------------------------------------------ */
  /*  Actions (this = app instance)                                       */
  /* ------------------------------------------------------------------ */

  #sync() { this.#collect(this.element.querySelector("form")); }

  static #onTab(ev, target) {
    this.#sync();
    this.tab = target.dataset.slTab;
    this.render();
  }

  static #onAddItem(ev, target) {
    this.#sync();
    const path = target.dataset.path;
    const list = getProperty(this.layout, path) ?? [];
    list.push(NEW_ITEMS[target.dataset.kind]());
    setProperty(this.layout, path, list);
    this.#changed();
    this.render();
  }

  static #onRemoveItem(ev, target) {
    this.#sync();
    const list = getProperty(this.layout, target.dataset.path);
    list.splice(Number(target.dataset.index), 1);
    this.#changed();
    this.render();
  }

  static #onMoveItem(ev, target) {
    this.#sync();
    const list = getProperty(this.layout, target.dataset.path);
    const i = Number(target.dataset.index), j = i + Number(target.dataset.dir);
    if (j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j], list[i]];
    this.#changed();
    this.render();
  }

  static #onPickFile(ev, target) {
    this.#sync();
    const path = target.dataset.target;
    const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
    new FP({
      type: "imagevideo",
      current: getProperty(this.layout, path) || "",
      callback: (file) => {
        setProperty(this.layout, path, file);
        this.#changed();
        this.render();
      }
    }).render(true);
  }

  static #onAddSlideFolder() {
    this.#sync();
    const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
    new FP({
      type: "folder",
      callback: async (folder, picker) => {
        const source = picker?.activeSource ?? "data";
        try {
          const res = await FP.browse(source, folder);
          const files = (res.files ?? []).filter((f) => /\.(png|webp|jpe?g|gif|avif|svg|webm|mp4)$/i.test(f)).sort();
          if (!files.length) return ui.notifications.warn("Session Lobby | No images found in that folder.");
          const list = this.layout.background.slides ??= [];
          for (const src of files) if (!list.some((x) => x.src === src)) list.push({ src, scale: 100, offsetX: 0, offsetY: 0 });
          ui.notifications.info(`Session Lobby | Added ${files.length} image(s).`);
          this.#changed();
          this.render();
        } catch (err) {
          console.error(err);
          ui.notifications.error("Session Lobby | Couldn't read that folder.");
        }
      }
    }).render(true);
  }

  static async #onSave() {
    this.#sync();
    await game.settings.set(MODULE_ID, "store", deepClone(this.store));
    this.dirty = false;
    ui.notifications.info("Session Lobby | Saved.");
    this.render();
  }

  static #onRevert() {
    this.#loadStore();
    Lobby.preview(this.layout);
    this.render();
  }

  static async #onNewLayout() {
    this.#sync();
    const template = await DialogV2.wait({
      window: { title: "New layout" },
      content: "<p>Which theme should the new layout use?</p>",
      buttons: Object.entries(TEMPLATES).map(([action, label]) => ({ action, label }))
    }).catch(() => null);
    if (!template || !(template in TEMPLATES)) return;
    const id = randomID();
    const name = `Layout ${Object.keys(this.store.layouts).length + 1}`;
    this.store.layouts[id] = template === "grimoire" ? grimoireLayout(name) : defaultLayout(name);
    Lobby.preview(this.store.layouts[id]);
    this.editing = id;
    this.#changed();
    this.render();
  }

  static #onDupLayout() {
    this.#sync();
    const id = randomID();
    const copy = deepClone(this.layout);
    copy.name = `${copy.name} (copy)`;
    this.store.layouts[id] = copy;
    this.editing = id;
    this.#changed();
    this.render();
  }

  static async #onDelLayout() {
    if (Object.keys(this.store.layouts).length <= 1) return ui.notifications.warn("You need at least one layout.");
    const ok = await DialogV2.confirm({ window: { title: "Delete layout" }, content: `<p>Delete <b>${esc(this.layout.name)}</b>?</p>` });
    if (!ok) return;
    delete this.store.layouts[this.editing];
    if (this.store.active === this.editing) this.store.active = Object.keys(this.store.layouts)[0];
    this.editing = this.store.active;
    this.#changed();
    this.render();
  }

  static #onMakeActive() {
    this.#sync();
    this.store.active = this.editing;
    this.#changed();
    this.render();
    ui.notifications.info(`"${this.layout.name}" will be the lobby players see once you save.`);
  }

  static #onExport() {
    this.#sync();
    const save = foundry.utils.saveDataToFile ?? globalThis.saveDataToFile;
    const name = (this.layout.name || "lobby").slugify?.() ?? "lobby";
    save(JSON.stringify(this.layout, null, 2), "application/json", `${name}.json`);
  }

  static async #onImport() {
    const text = await DialogV2.prompt({
      window: { title: "Import lobby layout" },
      content: `<p>Paste a layout JSON exported from Session Lobby. It is added as a new layout.</p><textarea name="json" style="width:100%;height:240px"></textarea>`,
      ok: { label: "Import", callback: (event, button) => button.form.elements.json.value }
    }).catch(() => null);
    if (!text) return;
    try {
      let data = JSON.parse(text);
      const incoming = data.layouts ? Object.values(data.layouts) : [data];
      this.#sync();
      for (const l of incoming) {
        const id = randomID();
        this.store.layouts[id] = mergeObject(defaultsFor(l.template), l, { inplace: false });
        this.editing = id;
      }
      this.#changed();
      Lobby.preview(this.layout);
      this.render();
    } catch (err) {
      ui.notifications.error("Session Lobby | That isn't valid layout JSON.");
    }
  }

  static #onTestAction(ev, target) {
    this.#sync();
    Lobby.runAction(getProperty(this.layout, target.dataset.path), "Test");
  }
}
