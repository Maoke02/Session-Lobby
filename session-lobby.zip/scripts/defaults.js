/**
 * Default lobby layout. Every field here is editable in the Lobby Designer.
 * Text fields accept tokens: {date} {time} {countdown} {dday} {nextDate}
 * {online} {total} {world} {music}
 */
export const MODULE_ID = "session-lobby";

export const ACTION_TYPES = {
  none: "Nothing",
  text: "Pop-up note (write it here)",
  journal: "Open Journal / Journal Page",
  actor: "Open Actor sheet",
  item: "Open Item sheet",
  macro: "Run Macro",
  scene: "View Scene (GM) / Pull everyone",
  url: "Open web link",
  vault: "Open the Party Vault",
  map: "Open the World Map",
  shops: "Open the Shops list (Stylish Shop)",
  shop: "Open one Stylish Shop",
  questlog: "Open the Quest Log (Quest Board)",
  relationships: "Open the Relationship Tracker",
  live: "Start session (GM only)"
};

export function blankAction(type = "none") {
  return { type, uuid: "", url: "", title: "", content: "" };
}

export function defaultLayout(name = "Main Lobby") {
  return {
    template: "skyterm",
    name,
    theme: {
      primary: "#12395e",
      accent: "#e4f55c",
      text: "#1d3f60",
      muted: "#5d7f9c",
      panel: "rgba(255,255,255,0.86)",
      headlineFont: "\"Playfair Display\", \"Georgia\", serif",
      displayFont: "\"Oswald\", \"Bebas Neue\", \"Arial Narrow\", sans-serif",
      bodyFont: "\"Signika\", \"Segoe UI\", sans-serif",
      ruled: true
    },
    background: {
      image: "",
      tint: "rgba(255,255,255,0.10)",
      art: "",
      artX: 62,
      artY: 0,
      artHeight: 108,
      artFlip: false,
      slides: [],
      slideSeconds: 8,
      fadeSeconds: 1.5,
      shuffle: false
    },
    brand: {
      logo: "",
      icon: "fa-solid fa-dragon",
      title: "THE LONG ROAD",
      subtitle: "BETWEEN THE ADVENTURES",
      meta1: "CAMPAIGN JOURNAL · NO. 017",
      meta2: "EST. 2026 · {world}",
      badge: "GM",
      badgeText: "DUNGEON MASTER · TABLE 1"
    },
    sideText: "AFTER THE LAST SESSION, BEFORE THE NEXT ONE",
    topBar: {
      show: true,
      idleText: "No music playing",
      label: "TAVERN BARD",
      sub1: "SCENE 01 / THE CROSSROADS",
      sub2: "AUTUMN ARC"
    },
    clock: {
      show: true,
      weatherIcon: "☀️",
      weather: "Sunny 24°C",
      countdownLabel: "NEXT SESSION IN",
      nextSession: "",
      presentLabel: "PRESENT",
      use24h: true
    },
    hero: {
      number: "01",
      label: "OUR FIRST ADVENTURE",
      tag: "ENTRY",
      line1: "Meet me at",
      line2: "the tavern.",
      tagline: "Four friends, one road, a lot of bad decisions.\nThe notebook for everything we find.",
      chips: [
        { icon: "", text: "{date}", style: "plain" },
        { icon: "fa-regular fa-clock", text: "{time}", style: "plain" },
        { icon: "fa-solid fa-location-dot", text: "THE CROSSROADS", style: "plain" },
        { icon: "fa-solid fa-calendar-day", text: "NEXT SESSION {dday}", style: "accent" }
      ]
    },
    cta: {
      small: "CONTINUE THE STORY",
      label: "PREVIOUSLY ON…",
      icon: "fa-solid fa-arrow-up-right",
      action: { type: "text", uuid: "", url: "", title: "Previously on…", content: "<p>Write a recap of the last session here — or switch this button to open a Journal page.</p>" }
    },
    buttons: [
      { icon: "fa-solid fa-thumbtack", label: "NOTICE", sub: "BOARD", action: blankAction("journal") },
      { icon: "fa-solid fa-envelope", label: "CONTACT", sub: "GM", action: blankAction("text") }
    ],
    cast: {
      title: "THE PARTY",
      showCount: true,
      items: [
        { name: "Hero One", image: "", userId: "", highlight: false, action: blankAction("actor") },
        { name: "Hero Two", image: "", userId: "", highlight: true, action: blankAction("actor") },
        { name: "Hero Three", image: "", userId: "", highlight: false, action: blankAction("actor") },
        { name: "Hero Four", image: "", userId: "", highlight: false, action: blankAction("actor") }
      ]
    },
    quotes: {
      show: true,
      interval: 9,
      items: [
        { speaker: "Hero Two", role: "BARD", text: "Wait. Play that part again." },
        { speaker: "Hero One", role: "FIGHTER", text: "I'm sure the door isn't trapped." }
      ]
    },
    cards: [
      { icon: "fa-solid fa-users", title: "OUR PARTY", sub: "THE PEOPLE", badge: "{online}/{total} online", action: blankAction("journal") },
      { icon: "fa-solid fa-calendar-days", title: "NEXT SESSION", sub: "THE TIMETABLE", badge: "{dday} {nextDate}", accent: true, action: blankAction("text") },
      { icon: "fa-solid fa-book-open", title: "FIELD NOTES", sub: "THE LITTLE MYSTERIES", badge: "7 notes · 1 new", action: blankAction("journal") },
      { icon: "fa-solid fa-handshake", title: "TABLE RULES", sub: "HOW WE PLAY TOGETHER", badge: "5 rules · read first", action: blankAction("journal") }
    ],
    footer: {
      left: "VOL. 01 — A LITTLE LATER, A LITTLE BRAVER.",
      right: "AN ORDINARY DAY. EXTRAORDINARY COMPANY."
    },
    options: {
      playersCanMinimize: true,
      showSidebar: false,
      showMusic: true
    }
  };
}

export const TEMPLATES = {
  skyterm: "Clear Sky (bright, notebook)",
  grimoire: "Grimoire (fantasy library)"
};

const link = (icon, label, type = "journal") => ({ icon, label, action: blankAction(type) });

export function grimoireLayout(name = "Grimoire Lobby") {
  return {
    template: "grimoire",
    name,
    theme: {
      navy: "#17203a",
      gold: "#c9a45c",
      parchment: "#f4e8d0",
      ink: "#1b1c29",
      inkSoft: "#4d4636",
      parchmentOpacity: 0.95,
      parchmentTexture: "",
      headlineFont: "\"Playfair Display\", \"Georgia\", serif",
      capsFont: "\"Cinzel\", \"Trajan Pro\", \"Georgia\", serif",
      bodyFont: "\"Cormorant Garamond\", \"Georgia\", serif"
    },
    background: {
      image: "",
      tint: "rgba(10,14,30,0.10)",
      art: "",
      artX: 60,
      artY: 12,
      artHeight: 78,
      artFlip: false,
      slides: [],
      slideSeconds: 8,
      fadeSeconds: 1.5,
      shuffle: false
    },
    banner: {
      show: true,
      crest: "",
      line1: "CHRONICLES",
      line2: "OF",
      line3: "A NEW DAWN",
      image: "",
      links: [
        link("fa-solid fa-calendar-days", "Sessions"),
        link("fa-solid fa-masks-theater", "Characters"),
        link("fa-solid fa-chess-rook", "Factions"),
        link("fa-solid fa-location-dot", "Locations"),
        link("fa-solid fa-scroll", "Quests"),
        link("fa-solid fa-dragon", "Bestiary"),
        link("fa-solid fa-gem", "Treasure"),
        link("fa-solid fa-store", "Shops", "shops")
      ]
    },
    nav: {
      show: true,
      items: [
        { ...link("fa-solid fa-house", "Home", "none"), active: true },
        { ...link("fa-solid fa-shield-halved", "Campaign"), active: false },
        { ...link("fa-solid fa-users", "Party"), active: false },
        { ...link("fa-solid fa-book", "Lore"), active: false },
        { ...link("fa-solid fa-map", "Map", "map"), active: false },
        { ...link("fa-solid fa-feather", "Notes"), active: false },
        { ...link("fa-solid fa-screwdriver-wrench", "Tools", "macro"), active: false }
      ]
    },
    hero: {
      eyebrow: "NEXT SESSION · {dday}",
      line1: "The Journey",
      line2: "Continues.",
      tagline: "A world of mysteries. A party of stories.\nWhat happens next is up to you.",
      buttonLabel: "OPEN SESSION NOTES",
      buttonAction: blankAction("journal")
    },
    cast: {
      title: "THE PARTY",
      showCount: true,
      items: ["Kimi", "Kali", "Memnok", "Poe", "Adaine"].map((n) => (
        { name: n, sub: "Lv 1 · Adventurer", image: "", userId: "", action: blankAction("actor") }))
    },
    cards: [
      { label: "CURRENT ARC", icon: "fa-solid fa-compass", title: "The Autumn Court", sub: "Thistledown Veil", image: "", action: blankAction("journal") },
      { label: "RECENT SESSION", icon: "fa-solid fa-hourglass-half", title: "Ashen Lady's Trial", sub: "Session 23 · Oct 1, 2026", image: "", action: blankAction("journal") },
      { label: "UPCOMING", icon: "fa-solid fa-clover", title: "The Green Dragon", sub: "Session 24 · {nextDate}", image: "", action: blankAction("journal") }
    ],
    links: {
      title: "QUICK LINKS",
      items: [
        link("fa-regular fa-file-lines", "Session Notes"),
        link("fa-solid fa-user-tie", "NPC Index"),
        link("fa-solid fa-map-location-dot", "World Map", "map"),
        link("fa-solid fa-chess-rook", "Factions"),
        link("fa-solid fa-sack-dollar", "Item Vault", "vault"),
        link("fa-solid fa-scale-balanced", "House Rules")
      ]
    },
    music: {
      show: true,
      title: "NOW PLAYING",
      cover: "",
      idleText: "The tavern is quiet…",
      playlistUuid: "",
      showVolume: true
    },
    calendar: {
      show: true,
      source: "core",
      months: "Hammer: 30\nAlturiak: 30\nChes: 30\nTarsakh: 30\nMirtul: 30\nKythorn: 30\nFlamerule: 30\nEleasis: 30\nEleint: 30\nMarpenoth: 30\nUktar: 30\nNightal: 30",
      weekdays: "First-day, Second-day, Third-day, Fourth-day, Fifth-day, Sixth-day, Seventh-day, Eighth-day, Ninth-day, Tenth-day",
      yearOffset: 1492,
      era: "DR",
      season: "",
      moon: "",
      startOffsetDays: 0,
      dayOffset: 0,
      yearAdjust: 0,
      manual: { year: 1492, month: 9, day: 14, hour: 18, minute: 40 },
      showTime: true,
      gmControls: true
    },
    clock: { nextSession: "", use24h: true },
    options: {
      playersCanMinimize: true,
      showSidebar: false,
      showMusic: true
    }
  };
}

export function defaultsFor(template) {
  return template === "grimoire" ? grimoireLayout() : defaultLayout();
}

export function defaultStore() {
  return { active: "main", layouts: { main: defaultLayout(), grimoire: grimoireLayout() } };
}
