/**
 * Pure HTML builders for the lobby overlay. No Foundry globals in here, so the
 * layout can be previewed outside Foundry too.
 */

export function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const VIDEO_RE = /\.(webm|mp4|m4v|ogv)(\?.*)?$/i;
export const isVideo = (src) => VIDEO_RE.test(src || "");

/** Replace {tokens} with live values. */
export function fmt(str, tokens) {
  return String(str ?? "").replace(/\{(\w+)\}/g, (m, key) => (key in tokens ? tokens[key] : m));
}

/** A span that keeps its template so the clock tick can re-fill it. */
export function live(template, tokens) {
  const t = String(template ?? "");
  if (!/\{\w+\}/.test(t)) return esc(t);
  return `<span data-fmt="${esc(t)}">${esc(fmt(t, tokens))}</span>`;
}

export function icon(cls) {
  return cls ? `<i class="${esc(cls)}"></i>` : "";
}

export function media(src, cls, extra = "") {
  if (!src) return "";
  if (isVideo(src)) return `<video class="${cls}" src="${esc(src)}" autoplay loop muted playsinline ${extra}></video>`;
  return `<img class="${cls}" src="${esc(src)}" alt="" ${extra}>`;
}

/** Slides for the character art (falls back to the single legacy `art` image). */
export function artSlides(bg = {}) {
  const slides = (bg.slides || []).filter((s) => s?.src);
  if (slides.length) return slides;
  return bg.art ? [{ src: bg.art, scale: 100, offsetX: 0, offsetY: 0 }] : [];
}

/** Character art as a crossfading slideshow. Rotation is driven by Lobby's clock tick. */
export function renderArt(bg, cls, defaultHeight = 100) {
  const slides = artSlides(bg);
  if (!slides.length) return "";
  const box = `left:${Number(bg.artX) || 0}%;bottom:${Number(bg.artY) || 0}%;height:${Number(bg.artHeight) || defaultHeight}%;`;
  const fade = Math.max(0, Number(bg.fadeSeconds ?? 1.5));
  const slidesHtml = slides.map((s, i) => {
    const scale = (Number(s.scale) || 100) / 100;
    const t = `transform:translateX(calc(-50% + ${Number(s.offsetX) || 0}%)) translateY(${-(Number(s.offsetY) || 0)}%) scale(${scale});transition-duration:${fade}s`;
    return `<div class="sl-slide${i === 0 ? " active" : ""}" style="${t}">${media(s.src, "sl-slide-media")}</div>`;
  }).join("");
  return `<div class="${cls} sl-slides${bg.artFlip ? " flip" : ""}" style="${box}" data-slides="${slides.length}"
    data-slide-secs="${Math.max(2, Number(bg.slideSeconds) || 8)}" data-shuffle="${bg.shuffle ? 1 : 0}">${slidesHtml}</div>`;
}

/** Build every token value from "now" + context. */
export function buildTokens(d, ctx) {
  const now = ctx.now ?? new Date();
  const locale = ctx.locale || undefined;
  const pad = (n) => String(n).padStart(2, "0");
  const weekday = now.toLocaleDateString(locale, { weekday: "short" });
  const time = d.clock?.use24h === false
    ? now.toLocaleTimeString(locale, { hour: "numeric", minute: "2-digit" })
    : `${pad(now.getHours())}:${pad(now.getMinutes())}`;

  let countdown = "--:--", dday = "D-?", nextDate = "TBD";
  const next = d.clock?.nextSession ? new Date(d.clock.nextSession) : null;
  if (next && !isNaN(next)) {
    const diff = next - now;
    const nextTime = d.clock?.use24h === false
      ? next.toLocaleTimeString(locale, { hour: "numeric", minute: "2-digit" })
      : `${pad(next.getHours())}:${pad(next.getMinutes())}`;
    nextDate = `${next.toLocaleDateString(locale, { weekday: "short" })} ${nextTime}`;
    const startOf = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate());
    const days = Math.round((startOf(next) - startOf(now)) / 86400000);
    dday = days > 0 ? `D+${days}` : days === 0 ? "D-DAY" : `D${days}`;
    if (diff <= 0) countdown = "NOW";
    else {
      const s = Math.floor(diff / 1000);
      const dd = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
      countdown = dd > 0 ? `${dd}d ${pad(hh)}:${pad(mm)}` : `${pad(hh)}:${pad(mm)}:${pad(ss)}`;
    }
  }

  return {
    date: `${pad(now.getMonth() + 1)} / ${pad(now.getDate())}`,
    longDate: now.toLocaleDateString(locale, { weekday: "short", month: "long", day: "numeric" }),
    weekday,
    time,
    clock: `${pad(now.getHours())}:${pad(now.getMinutes())}`,
    countdown, dday, nextDate,
    online: ctx.players?.filter((p) => p.active).length ?? 0,
    total: ctx.players?.length ?? 0,
    world: ctx.world ?? "",
    music: ctx.music || d.topBar?.idleText || d.music?.idleText || "",
    shops: ctx.shopsOpen ?? 0,
    ...calendarTokens(ctx.cal)
  };
}

/* ----------------------------------------------------------------------- */

function calendarTokens(c) {
  if (!c) return {};
  const pad = (n) => String(n).padStart(2, "0");
  return {
    calDay: c.day, calMonth: c.monthName, calYear: c.year, calEra: c.era, calWeekday: c.weekday,
    calTime: `${pad(c.hour)}:${pad(c.minute)}`, season: c.season, moon: c.moon,
    calDate: `${c.day} ${c.monthName} ${c.year}${c.era ? " " + c.era : ""}`
  };
}

export function renderTools(ctx) {
  const tools = [];
  if (ctx.isGM) {
    tools.push(`<div role="button" tabindex="0" data-sl-tool="edit"><i class="fa-solid fa-pen-ruler"></i> Design</div>`);
    if (!ctx.live) tools.push(`<div role="button" tabindex="0" class="go" data-sl-tool="start"><i class="fa-solid fa-play"></i> Start Session</div>`);
    else tools.push(`<div role="button" tabindex="0" data-sl-tool="end"><i class="fa-solid fa-stop"></i> Back to Lobby (all)</div>`);
    tools.push(`<div role="button" tabindex="0" data-sl-tool="hide"><i class="fa-solid fa-eye-slash"></i> Hide for me</div>`);
  } else if (ctx.canMinimize) {
    tools.push(`<div role="button" tabindex="0" data-sl-tool="hide"><i class="fa-solid fa-window-minimize"></i> Minimize</div>`);
  }
  if (ctx.preview) tools.unshift(`<span class="sl-preview-flag">PREVIEW · not saved</span>`);
  return `<div class="sl-tools">${tools.join("")}</div>`;
}

export function renderLobby(d, ctx) {
  if (d.template === "grimoire" && ctx.renderers?.grimoire) return ctx.renderers.grimoire(d, ctx);
  const t = buildTokens(d, ctx);
  const th = d.theme || {};
  const bg = d.background || {};

  const style = [
    `--sl-primary:${th.primary}`, `--sl-accent:${th.accent}`, `--sl-text:${th.text}`,
    `--sl-muted:${th.muted}`, `--sl-panel:${th.panel}`,
    `--sl-font-headline:${th.headlineFont}`, `--sl-font-display:${th.displayFont}`, `--sl-font-body:${th.bodyFont}`,
    `--sl-tint:${bg.tint || "transparent"}`
  ].map((s) => s.replace(/"/g, "'")).join(";");

  const parts = [];

  /* Background + art */
  parts.push(`<div class="sl-bg${bg.image ? "" : " sl-bg-default"}">${media(bg.image, "sl-bg-media")}</div>`);
  if (th.ruled) parts.push(`<div class="sl-ruled"></div>`);
  parts.push(`<div class="sl-tint"></div>`);
  parts.push(renderArt(bg, "sl-art", 100));

  /* Side text */
  if (d.sideText) parts.push(`<div class="sl-side">${esc(d.sideText)}</div>`);

  /* Brand */
  const b = d.brand || {};
  const head = [];
  head.push(`<header class="sl-brand">
    <div class="sl-logo">${b.logo ? media(b.logo, "sl-logo-media") : icon(b.icon || "fa-solid fa-star")}</div>
    <div class="sl-brand-text"><div class="sl-title">${live(b.title, t)}</div><div class="sl-subtitle">${live(b.subtitle, t)}</div></div>
    <div class="sl-brand-meta">
      ${b.meta1 ? `<div>${live(b.meta1, t)}</div>` : ""}
      ${b.meta2 ? `<div>${live(b.meta2, t)}</div>` : ""}
      ${b.badge || b.badgeText ? `<div class="sl-badge-row">${b.badge ? `<span class="sl-badge">${esc(b.badge)}</span>` : ""}${live(b.badgeText, t)}</div>` : ""}
    </div>
  </header>`);

  /* Now playing */
  const tb = d.topBar || {};
  if (tb.show) {
    head.push(`<div class="sl-topbar">
      <div class="sl-music${ctx.music ? " is-playing" : ""}">
        <span class="sl-dot"></span><span class="sl-music-name" data-music>${esc(t.music)}</span>
        <span class="sl-eq"><i></i><i></i><i></i><i></i></span>
        <span class="sl-music-label"><i class="fa-solid fa-tower-broadcast"></i> ${esc(tb.label)}</span>
      </div>
      <div class="sl-topbar-sub"><span class="sl-rule"></span>${live(tb.sub1, t)}<span class="sl-sub2">${live(tb.sub2, t)}</span></div>
    </div>`);
  }
  parts.push(`<div class="sl-headrow">${head.join("")}</div>`);

  /* Clock card */
  const c = d.clock || {};
  if (c.show) {
    const ticks = (ctx.players || []).map((p) =>
      `<span class="sl-tick${p.active ? " on" : ""}" data-tooltip="${esc(p.name)}">${p.active ? "✓" : ""}</span>`).join("");
    parts.push(`<div class="sl-clock sl-panel">
      <div class="sl-clock-top"><span data-fmt="{longDate}">${esc(t.longDate)}</span>
        <span class="sl-weather">${esc(c.weatherIcon)} ${live(c.weather, t)}</span></div>
      <div class="sl-clock-main">
        <div class="sl-clock-time" data-fmt="{clock}">${esc(t.clock)}</div>
        <div class="sl-clock-side">
          <div class="sl-countdown"><i class="fa-solid fa-bell"></i> ${esc(c.countdownLabel)} <b data-fmt="{countdown}">${esc(t.countdown)}</b></div>
          <div class="sl-present">${esc(c.presentLabel)} ${ticks} <b data-present>${t.online} / ${t.total}</b></div>
        </div>
      </div>
    </div>`);
  }

  /* Hero */
  const h = d.hero || {};
  const heroParts = [];
  heroParts.push(`<section class="sl-hero">
    <div class="sl-hero-head"><span class="sl-num">${esc(h.number)}</span><span class="sl-rule"></span>
      <span class="sl-hero-label">${live(h.label, t)}</span>${h.tag ? `<span class="sl-tag">${esc(h.tag)}</span>` : ""}</div>
    <h1 class="sl-headline"><span class="sl-l1">${live(h.line1, t)}</span><span class="sl-l2"><span class="sl-hl">${live(h.line2, t)}</span></span></h1>
    <div class="sl-tagline">${String(h.tagline || "").split("\n").map((l) => `<p>${live(l, t)}</p>`).join("")}</div>
    <div class="sl-chips">${(h.chips || []).map((ch) =>
      `<span class="sl-chip ${ch.style === "accent" ? "accent" : ""}">${icon(ch.icon)}${live(ch.text, t)}</span>`).join("")}</div>`);
  /* CTA + buttons (in the hero's flow so long text never overlaps) */
  const cta = d.cta || {};
  if (cta.label) {
    heroParts.push(`<div role="button" tabindex="0" class="sl-cta" data-sl-action="cta">
      <span class="sl-cta-text"><small>${live(cta.small, t)}</small><span>${live(cta.label, t)}</span></span>
      <span class="sl-cta-icon">${icon(cta.icon || "fa-solid fa-arrow-up-right")}</span><span class="sl-fold"></span>
    </div>`);
  }
  if (d.buttons?.length) {
    heroParts.push(`<div class="sl-buttons">${d.buttons.map((bt, i) => `
      <div role="button" tabindex="0" class="sl-btn sl-panel" data-sl-action="buttons.${i}">
        <span class="sl-ico">${icon(bt.icon)}</span><span><b>${live(bt.label, t)}</b><small>${live(bt.sub, t)}</small></span>
      </div>`).join("")}</div>`);
  }

  heroParts.push(`</section>`);
  parts.push(heroParts.join(""));


  /* Cast polaroids */
  const cast = d.cast || {};
  if (cast.items?.length) {
    const present = (it) => it.userId && ctx.players?.find((p) => p.id === it.userId)?.active;
    parts.push(`<aside class="sl-cast">
      <div class="sl-cast-title">${esc(cast.title)}${cast.showCount ? `<b>${String(cast.items.length).padStart(2, "0")} / ${String(cast.items.length).padStart(2, "0")}</b>` : ""}</div>
      <div class="sl-cast-list">${cast.items.map((it, i) => `
        <div role="button" tabindex="0" class="sl-polaroid${it.highlight ? " hl" : ""}${present(it) ? " online" : ""}" data-sl-action="cast.items.${i}" style="--tilt:${[-2, 1.5, -1, 2][i % 4]}deg">
          <span class="sl-pnum">${String(i + 1).padStart(2, "0")}</span><span class="sl-tape"></span>
          <span class="sl-photo">${it.image ? media(it.image, "") : `<i class="fa-solid fa-user"></i>`}</span>
          <span class="sl-pname">${esc(it.name)}</span>
          ${it.highlight ? `<span class="sl-star">★</span>` : ""}
        </div>`).join("")}</div>
    </aside>`);
  }

  /* Quote bubble */
  parts.push(renderQuote(d.quotes, ctx.quoteIndex));

  /* Bottom cards */
  if (d.cards?.length) {
    parts.push(`<nav class="sl-cards" style="--cols:${d.cards.length}">${d.cards.map((cd, i) => `
      <div role="button" tabindex="0" class="sl-card sl-panel" data-sl-action="cards.${i}">
        <span class="sl-cnum">${String(i + 1).padStart(2, "0")}</span>
        <span class="sl-ico">${icon(cd.icon)}</span>
        <span class="sl-card-text"><b>${live(cd.title, t)}</b><small>${live(cd.sub, t)}</small></span>
        ${cd.badge ? `<span class="sl-card-badge${cd.accent ? " accent" : ""}">${live(cd.badge, t)}</span>` : ""}
      </div>`).join("")}</nav>`);
  }

  /* Footer */
  const f = d.footer || {};
  parts.push(`<footer class="sl-footer"><span>${live(f.left, t)}</span><span>${live(f.right, t)}</span></footer>`);

  /* Toolbar */
  parts.push(renderTools(ctx));

  return `<div class="sl-stage" style="${esc(style)}">${parts.join("")}</div><div class="sl-modal-root"></div>`;
}

export function renderQuote(q, index = 0) {
  if (!q?.show || !q.items?.length) return "";
  const it = q.items[index % q.items.length];
  return `<div class="sl-quote sl-panel" data-sl-action="quote">
      <div class="sl-quote-head"><span class="sl-dot"></span><b>${esc(it.speaker)}</b><small>${esc(it.role)}</small><span class="sl-plus">+</span></div>
      <div class="sl-quote-text">${esc(it.text)}</div>
    </div>`;
}
