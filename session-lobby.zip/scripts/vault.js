/**
 * Party Vault — a shared party inventory + funds, stored on a regular Actor.
 *
 * - Items are real Item documents on the vault actor (full stats, sheets, compendium drops all work).
 * - Currency uses actor.system.currency when the system has it (dnd5e), otherwise a module flag.
 * - Anyone who owns the vault actor changes it directly; anyone else's change is relayed to the
 *   active GM through the module socket.
 */
import { MODULE_ID } from "./defaults.js";
import { esc } from "./render.js";
import { Lobby } from "./lobby.js";

const { ApplicationV2, DialogV2 } = foundry.applications.api;
const { getProperty, hasProperty, randomID, debounce } = foundry.utils;
const SOCKET = `module.${MODULE_ID}`;
const LOG_MAX = 60;

/* ====================================================================== */
/*  Data layer                                                             */
/* ====================================================================== */

export const Vault = {
  _pending: new Map(),

  get actor() {
    const uuid = game.settings.get(MODULE_ID, "vaultActor");
    if (!uuid) return null;
    try { return fromUuidSync(uuid); } catch { return null; }
  },

  /** Denominations: the system's own (dnd5e) or the module setting. */
  currencies() {
    const cfg = CONFIG.DND5E?.currencies;
    if (cfg && Object.keys(cfg).length) {
      return Object.entries(cfg).map(([key, v]) => ({
        key,
        label: game.i18n.localize(v.label ?? key),
        abbr: game.i18n.localize(v.abbreviation ?? key),
        conversion: Number(v.conversion) || 0
      }));
    }
    return String(game.settings.get(MODULE_ID, "vaultCurrencies") || "gp")
      .split(",").map((s) => s.trim()).filter(Boolean)
      .map((key) => ({ key, label: key.toUpperCase(), abbr: key, conversion: 0 }));
  },

  fundsPath(actor, key) {
    return hasProperty(actor, "system.currency") ? `system.currency.${key}` : `flags.${MODULE_ID}.currency.${key}`;
  },

  funds(actor) {
    const out = {};
    if (!actor) return out;
    for (const c of this.currencies()) out[c.key] = Number(getProperty(actor, this.fundsPath(actor, c.key))) || 0;
    return out;
  },

  /** Rough total in the base unit (gp for dnd5e) when the system gives conversions. */
  totalValue(funds) {
    let total = 0, any = false;
    for (const c of this.currencies()) {
      if (!c.conversion) continue;
      any = true;
      total += (funds[c.key] || 0) / c.conversion;
    }
    return any ? Math.round(total * 100) / 100 : null;
  },

  qty(item) {
    const q = getProperty(item, "system.quantity");
    return q === undefined ? 1 : Number(q) || 0;
  },

  hasQty(data) {
    return getProperty(data, "system.quantity") !== undefined;
  },

  findStack(actor, data) {
    return actor.items.find((i) => i.name === data.name && i.type === data.type && i.img === data.img);
  },

  /** Clean item data for creating a copy elsewhere. */
  itemData(item, qty) {
    const data = item.toObject();
    delete data._id;
    delete data.folder;
    delete data.sort;
    delete data.ownership;
    if (this.hasQty(data) && qty !== undefined) foundry.utils.setProperty(data, "system.quantity", qty);
    return data;
  },

  async addItemTo(actor, data, qty) {
    const stack = this.findStack(actor, data);
    if (stack && this.hasQty(data)) {
      return stack.update({ "system.quantity": this.qty(stack) + qty });
    }
    const copy = foundry.utils.deepClone(data);
    if (this.hasQty(copy)) foundry.utils.setProperty(copy, "system.quantity", qty);
    return actor.createEmbeddedDocuments("Item", [copy]);
  },

  async removeItemFrom(actor, itemId, qty) {
    const item = actor.items.get(itemId);
    if (!item) throw new Error("That item is no longer in the vault.");
    const have = this.qty(item);
    if (qty > have) throw new Error(`Only ${have} left.`);
    const data = this.itemData(item, qty);
    if (this.hasQty(item) && qty < have) await item.update({ "system.quantity": have - qty });
    else await item.delete();
    return data;
  },

  async adjustFunds(actor, delta) {
    const cur = this.funds(actor);
    const update = {};
    for (const [k, v] of Object.entries(delta)) {
      const next = (cur[k] || 0) + Number(v || 0);
      if (next < 0) throw new Error(`Not enough ${k} in the vault.`);
      update[this.fundsPath(actor, k)] = next;
    }
    if (Object.keys(update).length) await actor.update(update);
  },

  async appendLog(actor, user, text) {
    if (!text) return;
    const log = [...(actor.getFlag(MODULE_ID, "log") ?? [])];
    log.unshift({ t: Date.now(), user: user?.name ?? "?", text });
    await actor.setFlag(MODULE_ID, "log", log.slice(0, LOG_MAX));
  },

  /** Perform an operation on the vault actor. Runs on an owner (or the GM). */
  async execute(op, user) {
    const actor = this.actor;
    if (!actor) throw new Error("No party vault has been set up.");
    const withdrawing = op.kind === "takeItem" || (op.kind === "funds" && Object.values(op.delta ?? {}).some((v) => v < 0));
    if (withdrawing && !Bank.access(user).ok) throw new Error("Withdrawals can only be made at a bank.");
    let result = null;
    switch (op.kind) {
      case "addItem":
        await this.addItemTo(actor, op.data, op.qty);
        break;
      case "takeItem":
        result = await this.removeItemFrom(actor, op.itemId, op.qty);
        break;
      case "funds":
        await this.adjustFunds(actor, op.delta);
        break;
      case "deleteItem":
        if (!user?.isGM) throw new Error("Only the GM can discard items.");
        await actor.items.get(op.itemId)?.delete();
        break;
      default:
        throw new Error(`Unknown vault operation: ${op.kind}`);
    }
    await this.appendLog(actor, user, op.log);
    return result;
  },

  /** Run locally if we own the vault, otherwise ask the GM. */
  async run(op) {
    const actor = this.actor;
    if (!actor) throw new Error("No party vault has been set up.");
    if (actor.isOwner) return this.execute(op, game.user);
    const gm = game.users.activeGM ?? game.users.find((u) => u.isGM && u.active);
    if (!gm) throw new Error("The GM needs to be online to make changes to the party vault.");
    const id = randomID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this._pending.delete(id); reject(new Error("The GM didn't respond.")); }, 10000);
      this._pending.set(id, { resolve, reject, timer });
      game.socket.emit(SOCKET, { type: "vaultRequest", id, userId: game.user.id, op });
    });
  },

  async onSocket(msg) {
    if (msg?.type === "vaultRequest") {
      const responsible = game.users.activeGM ? game.users.activeGM.isSelf : (game.user.isGM && game.users.find((u) => u.isGM && u.active)?.isSelf);
      if (!responsible) return;
      try {
        const result = await this.execute(msg.op, game.users.get(msg.userId));
        game.socket.emit(SOCKET, { type: "vaultReply", id: msg.id, ok: true, result });
      } catch (err) {
        game.socket.emit(SOCKET, { type: "vaultReply", id: msg.id, ok: false, error: err.message });
      }
    } else if (msg?.type === "vaultReply") {
      const p = this._pending.get(msg.id);
      if (!p) return;
      clearTimeout(p.timer);
      this._pending.delete(msg.id);
      if (msg.ok) p.resolve(msg.result);
      else p.reject(new Error(msg.error));
    }
  },

  async createVaultActor() {
    const types = game.documentTypes?.Actor ?? Object.keys(game.system.documentTypes?.Actor ?? {});
    const type = types.includes("group") ? "group" : types.includes("npc") ? "npc" : types.find((t) => t !== "base") ?? types[0];
    const actor = await Actor.implementation.create({
      name: "Party Vault",
      type,
      img: "icons/svg/chest.svg",
      ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE }
    });
    await game.settings.set(MODULE_ID, "vaultActor", actor.uuid);
    return actor;
  }
};

/* ====================================================================== */
/*  Bank rules                                                             */
/* ====================================================================== */

/** Squares of empty space between two tokens' edges (0 = touching/adjacent). */
function tokenGap(a, b, size) {
  const ax = a.x + (a.width * size) / 2, ay = a.y + (a.height * size) / 2;
  const bx = b.x + (b.width * size) / 2, by = b.y + (b.height * size) / 2;
  const dx = Math.abs(ax - bx) - ((a.width + b.width) * size) / 2;
  const dy = Math.abs(ay - by) - ((a.height + b.height) * size) / 2;
  return Math.max(0, dx, dy) / size;
}

export const Bank = {
  _pill: null,
  _last: null,

  get cfg() {
    const saved = game.settings.get(MODULE_ID, "bank") ?? {};
    return { bankers: [], range: 1, open: "", ...saved };
  },

  async save(patch) {
    await game.settings.set(MODULE_ID, "bank", { ...this.cfg, ...patch });
  },

  bankerActors() {
    return this.cfg.bankers.map((u) => { try { return fromUuidSync(u); } catch { return null; } }).filter(Boolean);
  },

  /**
   * Can this user withdraw right now? GMs always can; players can when the GM has opened the bank,
   * or when a token they own stands within range of a banker's token on the scene they're viewing.
   */
  access(user = game.user) {
    if (!user) return { ok: false };
    if (user.isGM) return { ok: true, gm: true, name: "GM" };
    const cfg = this.cfg;
    if (cfg.open) return { ok: true, name: cfg.open, open: true };
    const bankers = this.bankerActors();
    if (!bankers.length) return { ok: false };
    const ids = new Set(bankers.map((a) => a.id));
    const vault = Vault.actor;
    const range = Math.max(0, Number(cfg.range) || 0);
    const scenes = user.viewedScene ? [game.scenes.get(user.viewedScene)].filter(Boolean) : game.scenes.contents;
    for (const scene of scenes) {
      const bankerTokens = scene.tokens.filter((t) => ids.has(t.actorId));
      if (!bankerTokens.length) continue;
      const mine = scene.tokens.filter((t) => t.actor && t.actor !== vault && !ids.has(t.actorId)
        && t.actor.testUserPermission(user, "OWNER"));
      const size = scene.grid?.size ?? scene.dimensions?.size ?? 100;
      for (const b of bankerTokens) for (const m of mine) {
        if (tokenGap(b, m, size) <= range) return { ok: true, name: b.name, near: true };
      }
    }
    return { ok: false };
  },

  /** How the current user may see the vault: "gm", "bank", "lobby" or null (not at all). */
  viewMode(user = game.user) {
    if (user.isGM) return "gm";
    if (this.access(user).ok) return "bank";
    if (Lobby.el) return "lobby";
    return null;
  },

  /** Re-check after tokens move, scenes change, the lobby opens/closes, etc. (players only). */
  evaluate: debounce(() => {
    if (game.user.isGM) return VaultApp.refresh();
    const a = Bank.access();
    const showPill = a.ok && !Lobby.el && !!Vault.actor;
    if (showPill) {
      if (!Bank._pill) {
        Bank._pill = document.createElement("div");
        Bank._pill.id = "session-lobby-bank-pill";
        Bank._pill.setAttribute("role", "button");
        Bank._pill.tabIndex = 0;
        Bank._pill.addEventListener("click", () => VaultApp.open());
        document.body.appendChild(Bank._pill);
        ui.notifications.info(`You're at the bank with ${a.name}. Click "Visit the bank" to use the party vault.`);
      }
      Bank._pill.innerHTML = `<i class="fa-solid fa-building-columns"></i> Visit the bank <small>${esc(a.name)}</small>`;
    } else if (Bank._pill) {
      Bank._pill.remove();
      Bank._pill = null;
    }
    if (a.ok !== Bank._last) { Bank._last = a.ok; VaultApp.refresh(); }
    if (!Bank.viewMode() && VaultApp.instance?.rendered) VaultApp.instance.close({ force: true });
  }, 150)
};

/* ====================================================================== */
/*  Window                                                                 */
/* ====================================================================== */

const fmtN = (n) => Number(n || 0).toLocaleString();

export class VaultApp extends ApplicationV2 {
  static #instance = null;

  static open() {
    if (!Bank.viewMode()) {
      ui.notifications.warn("The party vault can only be opened from the lobby, or at a bank.");
      return null;
    }
    this.#instance ??= new VaultApp();
    this.#instance.render(true);
    setTimeout(() => this.#instance?.bringToFront?.(), 50);
    return this.#instance;
  }

  static get instance() { return this.#instance; }

  /** Re-render when anything relevant changes. */
  static refresh = debounce(() => { if (VaultApp.#instance?.rendered) VaultApp.#instance.render(); }, 120);

  constructor(options = {}) {
    super(options);
    this.charId = game.user.character?.id ?? "";
    this.filter = "";
    this.amounts = {};
    this.removeFromSource = true;
  }

  static DEFAULT_OPTIONS = {
    id: "session-lobby-vault",
    classes: ["sl-vault-app"],
    tag: "div",
    window: { title: "Party Vault", icon: "fa-solid fa-sack-dollar", resizable: true },
    position: { width: 640, height: 760 },
    actions: {
      vaultCreate: VaultApp.#onCreate,
      vaultSheet: VaultApp.#onSheet,
      vaultUnlink: VaultApp.#onUnlink,
      vaultDeposit: VaultApp.#onDeposit,
      vaultWithdraw: VaultApp.#onWithdraw,
      vaultTake: VaultApp.#onTake,
      vaultDiscard: VaultApp.#onDiscard,
      vaultOpenItem: VaultApp.#onOpenItem,
      vaultLock: VaultApp.#onLock,
      vaultBankerRemove: VaultApp.#onBankerRemove,
      vaultBankToggle: VaultApp.#onBankToggle
    }
  };

  /** Actors this user can move things to/from. */
  get characters() {
    const vault = Vault.actor;
    return game.actors.filter((a) => a.isOwner && a !== vault && (a.type === "character" || !game.actors.some((x) => x.type === "character")))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  get character() {
    return this.charId ? game.actors.get(this.charId) : null;
  }

  /* ---------------------------------------------------------------- */

  async _renderHTML() {
    if (!Bank.viewMode()) {
      setTimeout(() => this.close({ force: true }), 0);
      return `<div class="slv slv-setup"><p>The vault is closed.</p></div>`;
    }
    const vault = Vault.actor;
    if (!vault) return this.#renderSetup();

    const curr = Vault.currencies();
    const funds = Vault.funds(vault);
    const total = Vault.totalValue(funds);
    const chars = this.characters;
    if (this.charId && !chars.some((c) => c.id === this.charId) && this.charId !== "__vault") this.charId = "";
    if (!this.charId && !game.user.isGM && chars[0]) this.charId = chars[0].id;
    const ch = this.character;
    const chFunds = ch ? Vault.funds(ch) : null;
    const items = vault.items.contents
      .filter((i) => !this.filter || i.name.toLowerCase().includes(this.filter.toLowerCase()))
      .sort((a, b) => a.type.localeCompare(b.type) || a.name.localeCompare(b.name));
    const log = vault.getFlag(MODULE_ID, "log") ?? [];
    const typeLabel = (t) => game.i18n.localize(CONFIG.Item.typeLabels?.[t] ?? t);
    const mode = Bank.viewMode();
    const access = Bank.access();
    const canWithdraw = access.ok;
    const lockedTip = `data-tooltip="Only at a bank"`;
    const bankerNames = Bank.bankerActors().map((a) => a.name);

    const charOptions = [
      `<option value="">— choose a character —</option>`,
      ...chars.map((c) => `<option value="${c.id}" ${c.id === this.charId ? "selected" : ""}>${esc(c.name)}</option>`),
      game.user.isGM ? `<option value="__vault" ${this.charId === "__vault" ? "selected" : ""}>Vault only (GM adjust)</option>` : ""
    ].join("");

    return `<div class="slv">
      <header class="slv-head">
        <img src="${esc(vault.img)}" alt="">
        <div><h2>${esc(vault.name)}</h2><small>${vault.items.size} item stack${vault.items.size === 1 ? "" : "s"}${total !== null ? ` · ≈ ${fmtN(total)} ${esc(curr.find((c) => c.conversion === 1)?.abbr ?? "")} total` : ""}</small></div>
        ${game.user.isGM ? `<span class="slv-gm">
          <button type="button" data-action="vaultSheet" data-tooltip="Open the vault actor"><i class="fa-solid fa-id-card"></i></button>
          <button type="button" data-action="vaultUnlink" data-tooltip="Use a different actor"><i class="fa-solid fa-link-slash"></i></button>
        </span>` : ""}
      </header>

      ${this.#statusLine(mode, access, bankerNames)}

      <section class="slv-funds">
        <h3>Party funds</h3>
        <div class="slv-coins">${curr.map((c) => `
          <div class="slv-coin c-${esc(c.key)}"><b>${fmtN(funds[c.key])}</b><small>${esc(c.abbr)}</small></div>`).join("")}
        </div>
        <div class="slv-transfer">
          <label>With <select data-slv="char">${charOptions}</select></label>
          ${chFunds ? `<span class="slv-carry">${esc(ch.name)} carries ${curr.map((c) => `${fmtN(chFunds[c.key])} ${esc(c.abbr)}`).join(" · ")}</span>` : ""}
        </div>
        <div class="slv-amounts">${curr.map((c) => `
          <label><input type="number" min="0" step="1" data-slv-amt="${esc(c.key)}" value="${this.amounts[c.key] || ""}" placeholder="0"><span>${esc(c.abbr)}</span></label>`).join("")}
        </div>
        <div class="slv-buttons">
          <button type="button" data-action="vaultDeposit"><i class="fa-solid fa-download"></i> Deposit</button>
          <button type="button" data-action="vaultWithdraw" ${canWithdraw ? "" : `disabled ${lockedTip}`}><i class="fa-solid ${canWithdraw ? "fa-upload" : "fa-lock"}"></i> Withdraw</button>
        </div>
      </section>

      <section class="slv-items">
        <div class="slv-items-head">
          <h3>Items</h3>
          <input type="search" data-slv="filter" placeholder="Search…" value="${esc(this.filter)}">
        </div>
        <div class="slv-drop" data-slv-drop>
          <i class="fa-solid fa-box-open"></i>
          <span>Drag items here from a character sheet, the Items sidebar or a compendium.</span>
          <label><input type="checkbox" data-slv="remove" ${this.removeFromSource ? "checked" : ""}> Remove from my character when I deposit</label>
        </div>
        <ol class="slv-list">${items.length ? items.map((i) => `
          <li>
            <img src="${esc(i.img)}" alt="">
            <a data-action="vaultOpenItem" data-item="${i.id}" class="slv-name">${esc(i.name)}</a>
            <span class="slv-type">${esc(typeLabel(i.type))}</span>
            ${Vault.hasQty(i) ? `<span class="slv-qty">×${fmtN(Vault.qty(i))}</span>` : `<span class="slv-qty"></span>`}
            <button type="button" data-action="vaultTake" data-item="${i.id}" ${canWithdraw ? `data-tooltip="Take"` : `disabled ${lockedTip}`}><i class="fa-solid ${canWithdraw ? "fa-hand" : "fa-lock"}"></i> Take</button>
            ${game.user.isGM ? `<button type="button" class="slv-x" data-action="vaultDiscard" data-item="${i.id}" data-tooltip="Discard (GM)"><i class="fa-solid fa-trash"></i></button>` : ""}
          </li>`).join("") : `<li class="slv-empty">${this.filter ? "Nothing matches." : "The vault is empty."}</li>`}
        </ol>
      </section>

      ${game.user.isGM ? this.#gmBankSection(vault) : ""}

      <section class="slv-log">
        <h3>Ledger</h3>
        <ol>${log.slice(0, 15).map((e) => `<li><time>${new Date(e.t).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</time> <b>${esc(e.user)}</b> ${esc(e.text)}</li>`).join("") || "<li class='slv-empty'>No activity yet.</li>"}</ol>
      </section>
    </div>`;
  }

  #statusLine(mode, access, bankerNames) {
    const where = bankerNames.length ? `Withdrawals happen at the bank — find ${bankerNames.map(esc).join(" or ")}.` : "Withdrawals happen at a bank.";
    if (mode === "gm") {
      const cfg = Bank.cfg;
      return `<div class="slv-status gm"><i class="fa-solid fa-crown"></i><span>GM view — no limits. ${cfg.open ? `The bank is <b>open for everyone</b>.` : bankerNames.length ? `Players can withdraw next to ${bankerNames.map(esc).join(" or ")}.` : `No bankers yet — add one below.`}</span></div>`;
    }
    if (mode === "bank") {
      return `<div class="slv-status bank"><i class="fa-solid fa-building-columns"></i><span>${access.open ? "The bank is open." : `You're at the bank with <b>${esc(access.name)}</b>.`} Deposits and withdrawals are open.</span></div>`;
    }
    return `<div class="slv-status lobby"><i class="fa-solid fa-scroll"></i><span>Lobby view — you can look and deposit. ${where}</span></div>`;
  }

  #gmBankSection(vault) {
    const cfg = Bank.cfg;
    const bankers = Bank.bankerActors();
    const playersOwn = game.users.some((u) => !u.isGM && vault.testUserPermission(u, "OWNER"));
    return `<section class="slv-bank">
      <h3>Bank (GM)</h3>
      ${playersOwn ? `<div class="slv-warn"><i class="fa-solid fa-triangle-exclamation"></i>
        <span>Players own the vault actor, so they could skip the bank by opening it from the Actors sidebar.</span>
        <button type="button" data-action="vaultLock"><i class="fa-solid fa-lock"></i> Lock it</button></div>` : ""}
      <p class="slv-hint">Drag an NPC (Actor) onto this window to make them a banker. When a player's token stands near a banker's token, they can withdraw.</p>
      <ul class="slv-bankers">${bankers.map((a) => `
        <li><img src="${esc(a.img)}" alt=""><span>${esc(a.name)}</span>
          <button type="button" class="slv-x" data-action="vaultBankerRemove" data-uuid="${esc(a.uuid)}" data-tooltip="No longer a banker"><i class="fa-solid fa-xmark"></i></button></li>`).join("")
        || `<li class="slv-empty">No bankers yet.</li>`}</ul>
      <div class="slv-bank-row">
        <label>Reach <input type="number" min="0" step="1" data-slv="range" value="${Number(cfg.range) || 0}"> empty squares between tokens</label>
        <button type="button" data-action="vaultBankToggle">${cfg.open
          ? `<i class="fa-solid fa-door-closed"></i> Close the bank`
          : `<i class="fa-solid fa-door-open"></i> Open the bank for everyone`}</button>
      </div>
    </section>`;
  }

  #renderSetup() {
    if (!game.user.isGM) return `<div class="slv slv-setup"><i class="fa-solid fa-sack-dollar"></i><p>The GM hasn't set up the party vault yet.</p></div>`;
    return `<div class="slv slv-setup" data-slv-drop>
      <i class="fa-solid fa-sack-dollar"></i>
      <p>The vault keeps its items and coins on an Actor, so everything stays a real Foundry item.</p>
      <button type="button" data-action="vaultCreate"><i class="fa-solid fa-plus"></i> Create a "Party Vault" actor</button>
      <p class="slv-or">…or drag an existing Actor (e.g. your party Group) onto this window.</p>
    </div>`;
  }

  _replaceHTML(result, content) {
    const scroll = content.querySelector(".slv-list")?.scrollTop ?? 0;
    content.innerHTML = result;
    const list = content.querySelector(".slv-list");
    if (list) list.scrollTop = scroll;

    content.querySelector('[data-slv="char"]')?.addEventListener("change", (ev) => { this.charId = ev.target.value; this.render(); });
    content.querySelector('[data-slv="range"]')?.addEventListener("change", (ev) => Bank.save({ range: Math.max(0, Math.floor(Number(ev.target.value) || 0)) }));
    content.querySelector('[data-slv="remove"]')?.addEventListener("change", (ev) => { this.removeFromSource = ev.target.checked; });
    const filter = content.querySelector('[data-slv="filter"]');
    filter?.addEventListener("input", debounce((ev) => { this.filter = ev.target.value; this.render(); }, 250));
    for (const inp of content.querySelectorAll("[data-slv-amt]")) {
      inp.addEventListener("input", () => { this.amounts[inp.dataset.slvAmt] = Math.max(0, Math.floor(Number(inp.value) || 0)); });
    }
    // Whole window accepts drops.
    content.addEventListener("dragover", (ev) => { ev.preventDefault(); content.classList.add("slv-dragging"); });
    content.addEventListener("dragleave", (ev) => { if (!content.contains(ev.relatedTarget)) content.classList.remove("slv-dragging"); });
    content.addEventListener("drop", (ev) => { content.classList.remove("slv-dragging"); this.#onDrop(ev); });
  }

  /* ---------------------------------------------------------------- */
  /*  Drops                                                             */
  /* ---------------------------------------------------------------- */

  async #onDrop(ev) {
    ev.preventDefault();
    let data;
    try { data = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch { return; }

    // Linking an actor as the vault (GM, during setup or after unlinking).
    if (data.type === "Actor" && game.user.isGM && !Vault.actor) {
      const actor = await fromUuid(data.uuid);
      if (actor) await game.settings.set(MODULE_ID, "vaultActor", actor.uuid);
      return this.render();
    }
    // Making an actor a banker (GM).
    if (data.type === "Actor" && game.user.isGM) {
      const actor = await fromUuid(data.uuid);
      if (!actor || actor === Vault.actor) return;
      const bankers = Bank.cfg.bankers;
      if (!bankers.includes(actor.uuid)) await Bank.save({ bankers: [...bankers, actor.uuid] });
      ui.notifications.info(`${actor.name} is now a banker.`);
      return this.render();
    }
    if (data.type !== "Item") return;

    const vault = Vault.actor;
    if (!vault) return;
    const item = await Item.implementation.fromDropData(data);
    if (!item) return;
    if (item.parent === vault) return;
    if (game.system.id === "dnd5e" && !Vault.hasQty(item)) {
      return ui.notifications.warn(`${item.name} isn't a physical item, so it can't go in the vault.`);
    }

    const have = Vault.qty(item);
    const qty = have > 1 ? await this.#askQty(`Deposit ${item.name}`, have) : 1;
    if (!qty) return;

    const fromActor = item.parent instanceof Actor && item.parent.isOwner ? item.parent : null;
    const taking = fromActor && this.removeFromSource;
    try {
      await Vault.run({
        kind: "addItem",
        data: Vault.itemData(item, qty),
        qty,
        log: `deposited ${item.name}${Vault.hasQty(item) ? ` ×${qty}` : ""}${fromActor ? ` from ${fromActor.name}` : ""}`
      });
      if (taking) {
        if (Vault.hasQty(item) && qty < have) await item.update({ "system.quantity": have - qty });
        else await item.delete();
      }
    } catch (err) {
      ui.notifications.error(err.message);
    }
    this.render();
  }

  async #askQty(title, max) {
    const value = await DialogV2.prompt({
      window: { title },
      content: `<div class="form-group"><label>How many? (max ${max})</label><input type="number" name="qty" min="1" max="${max}" value="${max}" autofocus></div>`,
      ok: { label: "OK", callback: (event, button) => button.form.elements.qty.valueAsNumber }
    }).catch(() => null);
    if (!value || value < 1) return 0;
    return Math.min(max, Math.floor(value));
  }

  #amounts() {
    const out = {};
    for (const [k, v] of Object.entries(this.amounts)) if (v > 0) out[k] = v;
    return out;
  }

  #describe(amounts) {
    const curr = Vault.currencies();
    return Object.entries(amounts).map(([k, v]) => `${fmtN(v)} ${curr.find((c) => c.key === k)?.abbr ?? k}`).join(", ");
  }

  /* ---------------------------------------------------------------- */
  /*  Actions (this = app)                                              */
  /* ---------------------------------------------------------------- */

  static async #onCreate() {
    await Vault.createVaultActor();
    ui.notifications.info("Session Lobby | Party Vault actor created. Players have Owner permission on it so they can use the vault directly.");
    this.render();
  }

  static #onSheet() {
    Vault.actor?.sheet.render(true);
  }

  static async #onUnlink() {
    const ok = await DialogV2.confirm({ window: { title: "Change vault actor" }, content: "<p>Stop using this actor as the vault? Its items and coins stay on the actor; you can link it again by dragging it here.</p>" });
    if (!ok) return;
    await game.settings.set(MODULE_ID, "vaultActor", "");
    this.render();
  }

  static async #onDeposit() {
    const amounts = this.#amounts();
    if (!Object.keys(amounts).length) return ui.notifications.warn("Enter an amount first.");
    const ch = this.character;
    const vaultOnly = this.charId === "__vault" && game.user.isGM;
    if (!ch && !vaultOnly) return ui.notifications.warn("Choose which character the money comes from.");
    try {
      if (ch) {
        const have = Vault.funds(ch);
        for (const [k, v] of Object.entries(amounts)) if ((have[k] || 0) < v) throw new Error(`${ch.name} doesn't have ${v} ${k}.`);
      }
      await Vault.run({ kind: "funds", delta: amounts, log: `deposited ${this.#describe(amounts)}${ch ? ` from ${ch.name}` : ""}` });
      if (ch) {
        const have = Vault.funds(ch);
        const update = {};
        for (const [k, v] of Object.entries(amounts)) update[Vault.fundsPath(ch, k)] = (have[k] || 0) - v;
        await ch.update(update);
      }
      this.amounts = {};
    } catch (err) {
      ui.notifications.error(err.message);
    }
    this.render();
  }

  static async #onWithdraw() {
    if (!Bank.access().ok) return ui.notifications.warn("Withdrawals can only be made at a bank.");
    const amounts = this.#amounts();
    if (!Object.keys(amounts).length) return ui.notifications.warn("Enter an amount first.");
    const ch = this.character;
    const vaultOnly = this.charId === "__vault" && game.user.isGM;
    if (!ch && !vaultOnly) return ui.notifications.warn("Choose which character receives the money.");
    try {
      const negative = Object.fromEntries(Object.entries(amounts).map(([k, v]) => [k, -v]));
      await Vault.run({ kind: "funds", delta: negative, log: `withdrew ${this.#describe(amounts)}${ch ? ` to ${ch.name}` : ""}` });
      if (ch) {
        const have = Vault.funds(ch);
        const update = {};
        for (const [k, v] of Object.entries(amounts)) update[Vault.fundsPath(ch, k)] = (have[k] || 0) + v;
        await ch.update(update);
      }
      this.amounts = {};
    } catch (err) {
      ui.notifications.error(err.message);
    }
    this.render();
  }

  static async #onTake(ev, target) {
    if (!Bank.access().ok) return ui.notifications.warn("You can only take items out at a bank.");
    const vault = Vault.actor;
    const item = vault?.items.get(target.dataset.item);
    if (!item) return;
    const ch = this.character;
    const vaultOnly = this.charId === "__vault" && game.user.isGM;
    if (!ch && !vaultOnly) return ui.notifications.warn("Choose which character takes it (top of the window).");
    const have = Vault.qty(item);
    const qty = have > 1 ? await this.#askQty(`Take ${item.name}`, have) : 1;
    if (!qty) return;
    try {
      const data = await Vault.run({
        kind: "takeItem", itemId: item.id, qty,
        log: `took ${item.name}${Vault.hasQty(item) ? ` ×${qty}` : ""}${ch ? ` for ${ch.name}` : " out of the vault"}`
      });
      if (ch && data) await Vault.addItemTo(ch, data, qty);
    } catch (err) {
      ui.notifications.error(err.message);
    }
    this.render();
  }

  static async #onDiscard(ev, target) {
    const item = Vault.actor?.items.get(target.dataset.item);
    if (!item) return;
    const ok = await DialogV2.confirm({ window: { title: "Discard item" }, content: `<p>Remove <b>${esc(item.name)}</b> from the vault entirely?</p>` });
    if (!ok) return;
    try { await Vault.run({ kind: "deleteItem", itemId: item.id, log: `discarded ${item.name}` }); } catch (err) { ui.notifications.error(err.message); }
    this.render();
  }

  static async #onOpenItem(ev, target) {
    const item = Vault.actor?.items.get(target.dataset.item);
    if (!item) return;
    if (item.testUserPermission?.(game.user, "OBSERVER")) return item.sheet.render(true);
    // Locked vault: show a read-only card instead of the sheet.
    const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
    const desc = await TE.enrichHTML(getProperty(item, "system.description.value") ?? "", { secrets: false });
    await DialogV2.prompt({
      window: { title: item.name },
      content: `<div class="slv-card"><img src="${esc(item.img)}" alt=""><div>${desc || "<p><i>No description.</i></p>"}</div></div>`,
      ok: { label: "Close" }
    }).catch(() => null);
  }

  static async #onLock() {
    const vault = Vault.actor;
    if (!vault) return;
    const NONE = CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE;
    const ownership = { default: NONE };
    for (const u of game.users) if (!u.isGM) ownership[u.id] = NONE;
    await vault.update({ ownership });
    ui.notifications.info("Session Lobby | The vault actor is now hidden from players; they can only use it through the vault window.");
    this.render();
  }

  static async #onBankerRemove(ev, target) {
    await Bank.save({ bankers: Bank.cfg.bankers.filter((u) => u !== target.dataset.uuid) });
    this.render();
  }

  static async #onBankToggle() {
    const cfg = Bank.cfg;
    if (cfg.open) await Bank.save({ open: "" });
    else await Bank.save({ open: Bank.bankerActors()[0]?.name || "The bank" });
    this.render();
  }
}

/* ====================================================================== */
/*  Wiring                                                                 */
/* ====================================================================== */

export function registerVault() {
  game.settings.register(MODULE_ID, "vaultActor", {
    scope: "world", config: false, type: String, default: "",
    onChange: () => VaultApp.refresh()
  });
  game.settings.register(MODULE_ID, "bank", {
    scope: "world", config: false, type: Object, default: { bankers: [], range: 1, open: "" },
    onChange: () => { Bank.evaluate(); VaultApp.refresh(); }
  });
  game.settings.register(MODULE_ID, "vaultCurrencies", {
    name: "Party Vault currencies",
    hint: "Comma-separated coin types, used only when your game system doesn't define its own (dnd5e does).",
    scope: "world", config: true, type: String, default: "pp, gp, ep, sp, cp"
  });
  game.keybindings.register(MODULE_ID, "openVault", {
    name: "Open the Party Vault",
    editable: [],
    onDown: () => { VaultApp.open(); return true; }
  });

  const relevant = (doc) => {
    const vault = Vault.actor;
    const actor = doc instanceof Actor ? doc : doc.parent;
    return actor && (actor === vault || actor.isOwner);
  };
  // Bank proximity: re-check whenever tokens move or the view changes.
  for (const hook of ["updateToken", "createToken", "deleteToken", "canvasReady", "sessionLobbyRefresh"]) {
    Hooks.on(hook, () => Bank.evaluate());
  }
  Hooks.on("updateUser", (user, change) => { if (user.isSelf && "viewedScene" in change) Bank.evaluate(); });
  for (const hook of ["createItem", "updateItem", "deleteItem", "updateActor"]) {
    Hooks.on(hook, (doc) => { if (relevant(doc)) VaultApp.refresh(); });
  }
}

export function registerVaultSocket() {
  game.socket.on(SOCKET, (msg) => Vault.onSocket(msg));
}
