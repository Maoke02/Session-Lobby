import { esc, live, icon, media, buildTokens, renderTools, renderArt } from "./render.js";

/** Deterministic jagged polygon for torn-parchment edges. */
function tornClip(seed = 7, steps = 22, depth = 1.6) {
  let x = seed;
  const rnd = () => ((x = (x * 9301 + 49297) % 233280) / 233280);
  const pts = [];
  for (let i = 0; i <= steps; i++) pts.push(`${(i / steps) * 100}% ${rnd() * depth}%`);
  for (let i = 1; i <= steps; i++) pts.push(`${100 - rnd() * depth}% ${(i / steps) * 100}%`);
  for (let i = steps - 1; i >= 0; i--) pts.push(`${(i / steps) * 100}% ${100 - rnd() * depth}%`);
  for (let i = steps - 1; i >= 1; i--) pts.push(`${rnd() * depth}% ${(i / steps) * 100}%`);
  return `polygon(${pts.join(",")})`;
}
const HERO_CLIP = tornClip(11, 26, 2.2);

const COMPASS = `<svg viewBox="0 0 100 100" class="gr-compass" aria-hidden="true">
  <circle cx="50" cy="50" r="38" fill="none" stroke="currentColor" stroke-width=".8"/>
  <circle cx="50" cy="50" r="30" fill="none" stroke="currentColor" stroke-width=".5" stroke-dasharray="1 2"/>
  <path d="M50 4 L55 45 L96 50 L55 55 L50 96 L45 55 L4 50 L45 45Z" fill="currentColor" opacity=".9"/>
  <path d="M50 22 L53 47 L78 50 L53 53 L50 78 L47 53 L22 50 L47 47Z" fill="var(--gr-navy)" stroke="currentColor" stroke-width=".6" transform="rotate(45 50 50)"/>
  <circle cx="50" cy="50" r="3" fill="var(--gr-navy)" stroke="currentColor"/>
</svg>`;

const pad = (n) => String(n).padStart(2, "0");

/** CSS url() inside a variable resolves against the stylesheet, so pass a full URL. */
function absUrl(src) {
  try { return new URL(src, document.baseURI).href; } catch { return src; }
}
const fmtTime = (s) => (isFinite(s) && s > 0 ? `${Math.floor(s / 60)}:${pad(Math.floor(s % 60))}` : "0:00");

export function renderGrimoire(d, ctx) {
  const t = buildTokens(d, ctx);
  const th = d.theme || {};
  const bg = d.background || {};
  const style = [
    `--gr-navy:${th.navy}`, `--gr-gold:${th.gold}`, `--gr-parch:${th.parchment}`, `--gr-ink:${th.ink}`, `--gr-ink-soft:${th.inkSoft}`,
    `--gr-parch-alpha:${th.parchmentOpacity ?? 0.95}`,
    `--gr-font-head:${th.headlineFont}`, `--gr-font-caps:${th.capsFont}`, `--gr-font-body:${th.bodyFont}`,
    `--gr-tint:${bg.tint || "transparent"}`,
    th.parchmentTexture ? `--gr-texture:url('${absUrl(th.parchmentTexture)}')` : ""
  ].filter(Boolean).map((s) => s.replace(/"/g, "'")).join(";");

  const P = [];

  /* Background */
  P.push(`<div class="gr-bg${bg.image ? "" : " gr-bg-default"}">${media(bg.image, "gr-cover")}</div><div class="gr-tint"></div>`);

  /* Hero parchment (behind the art) */
  const h = d.hero || {};
  P.push(`<section class="gr-hero">
    <div class="gr-hero-paper" style="clip-path:${HERO_CLIP}"></div>
    <div class="gr-hero-body">
      <div class="gr-eyebrow">${live(h.eyebrow, t)}<span class="gr-eyebrow-rule"></span><span class="gr-diamond">◆</span></div>
      <h1 class="gr-headline"><span>${live(h.line1, t)}</span><span>${live(h.line2, t)}</span></h1>
      <div class="gr-tagline">${String(h.tagline || "").split("\n").map((l) => `<p>${live(l, t)}</p>`).join("")}</div>
      ${h.buttonLabel ? `<div role="button" tabindex="0" class="gr-pill" data-sl-action="hero.button">${live(h.buttonLabel, t)} <i class="fa-solid fa-arrow-right"></i></div>` : ""}
    </div>
  </section>`);

  /* Character art */
  P.push(renderArt(bg, "gr-art", 80));

  /* Left banner */
  const b = d.banner || {};
  if (b.show !== false) {
    P.push(`<aside class="gr-banner"><div class="gr-banner-inner">
      <div class="gr-crest">${b.crest ? media(b.crest, "gr-crest-media") : COMPASS}</div>
      <div class="gr-banner-title">
        ${b.line1 ? `<div class="gr-bt1">${live(b.line1, t)}</div>` : ""}
        ${b.line2 ? `<div class="gr-bt2">${live(b.line2, t)}</div>` : ""}
        ${b.line3 ? `<div class="gr-bt1">${live(b.line3, t)}</div>` : ""}
      </div>
      <div class="gr-orn"><span></span>✦<span></span></div>
      <nav class="gr-banner-links">${(b.links || []).map((l, i) => `
        <div role="button" tabindex="0" data-sl-action="banner.links.${i}">${icon(l.icon)}<span>${live(l.label, t)}</span></div>`).join("")}</nav>
      <div class="gr-orn small"><span></span>✧<span></span></div>
      <div class="gr-banner-img${b.image ? "" : " empty"}">${media(b.image, "gr-cover")}</div>
    </div></aside>`);
  }

  /* Top nav */
  const nav = d.nav || {};
  if (nav.show !== false && nav.items?.length) {
    P.push(`<nav class="gr-nav gr-paper">${nav.items.map((n, i) => `
      <div role="button" tabindex="0" class="${n.active ? "active" : ""}" data-sl-action="nav.items.${i}">${icon(n.icon)}<span>${live(n.label, t)}</span></div>`).join("<i class=\"gr-sep\"></i>")}</nav>`);
  }

  /* Calendar */
  if (d.calendar?.show !== false && ctx.cal) P.push(renderCalWidget(ctx.cal, d.calendar));

  /* Party */
  const cast = d.cast || {};
  if (cast.items?.length) {
    const linked = cast.items.filter((it) => it.userId);
    const onlineCount = linked.filter((it) => ctx.players?.find((p) => p.id === it.userId)?.active).length;
    const count = linked.length ? `${onlineCount}/${linked.length}` : `${cast.items.length}/${cast.items.length}`;
    P.push(`<aside class="gr-party gr-paper gr-framed">
      <header class="gr-panel-head"><span class="gr-cross">✝</span>${esc(cast.title)}<span class="gr-panel-rule"></span>${cast.showCount ? `<b>${count}</b>` : ""}</header>
      ${cast.items.map((it, i) => {
        const online = it.userId && ctx.players?.find((p) => p.id === it.userId)?.active;
        return `<div role="button" tabindex="0" class="gr-member${online ? " online" : ""}" data-sl-action="cast.items.${i}">
          <span class="gr-portrait">${it.image ? media(it.image, "") : `<i class="fa-solid fa-user"></i>`}</span>
          <span class="gr-member-text"><b>${esc(it.name)}</b><small>${live(it.sub, t)}</small></span>
        </div>`;
      }).join("")}
    </aside>`);
  }

  /* Feature cards */
  if (d.cards?.length) {
    P.push(`<div class="gr-cards" style="--cols:${d.cards.length}">${d.cards.map((c, i) => `
      <div role="button" tabindex="0" class="gr-card" data-sl-action="cards.${i}">
        <span class="gr-card-img${c.image ? "" : " empty"}">${media(c.image, "gr-cover")}</span>
        <span class="gr-card-label">${icon(c.icon)} ${live(c.label, t)}</span>
        <span class="gr-card-foot">
          <span class="gr-card-text"><b>${live(c.title, t)}</b><small>✦ ${live(c.sub, t)}</small></span>
          <span class="gr-card-go"><i class="fa-solid fa-arrow-right"></i></span>
        </span>
      </div>`).join("")}</div>`);
  }

  /* Quick links */
  const ql = d.links || {};
  if (ql.items?.length) {
    P.push(`<aside class="gr-links gr-paper gr-framed">
      <header class="gr-panel-head"><span class="gr-cross">✝</span>${esc(ql.title)}<span class="gr-panel-rule"></span></header>
      <div class="gr-links-grid">${ql.items.map((l, i) => `
        <div role="button" tabindex="0" data-sl-action="links.items.${i}">${icon(l.icon)}<span>${live(l.label, t)}</span></div>`).join("")}</div>
    </aside>`);
  }

  /* Music player */
  const m = d.music || {};
  if (m.show !== false) {
    const tr = ctx.track;
    P.push(`<div class="gr-music gr-paper gr-framed${tr?.playing ? " playing" : ""}">
      <span class="gr-music-cover">${m.cover ? media(m.cover, "gr-cover") : `<i class="fa-solid fa-compact-disc"></i>`}</span>
      <span class="gr-music-info">
        <small>${esc(m.title)}</small>
        <b data-music>${esc(tr?.name || m.idleText)}</b>
        <span class="gr-music-pl" data-music-pl>${esc(tr?.playlist || "")}</span>
      </span>
      <span class="gr-music-progress">
        <span class="gr-time" data-music-cur>${fmtTime(tr?.current)}</span>
        <span class="gr-bar"><span data-music-bar style="width:${Math.round((tr?.progress || 0) * 100)}%"></span></span>
        <span class="gr-time" data-music-dur>${fmtTime(tr?.duration)}</span>
      </span>
      ${ctx.isGM ? `<span class="gr-music-ctrl">
        <div role="button" tabindex="0" data-sl-music="prev" data-tooltip="Previous"><i class="fa-solid fa-backward-step"></i></div>
        <div role="button" tabindex="0" class="main" data-sl-music="toggle" data-tooltip="Play / Stop"><i class="fa-solid ${tr?.playing ? "fa-pause" : "fa-play"}"></i></div>
        <div role="button" tabindex="0" data-sl-music="next" data-tooltip="Next"><i class="fa-solid fa-forward-step"></i></div>
      </span>` : `<span class="gr-eq"><i></i><i></i><i></i><i></i><i></i></span>`}
      ${m.showVolume !== false ? `<label class="gr-vol" data-tooltip="Your music volume"><i class="fa-solid fa-volume-high"></i>
        <input type="range" min="0" max="1" step="0.01" value="${Number(ctx.volume ?? 0.5)}" data-sl-volume></label>` : ""}
    </div>`);
  }

  P.push(renderTools(ctx));
  return `<div class="sl-stage gr" style="${esc(style)}">${P.join("")}</div><div class="sl-modal-root"></div>`;
}

export function renderCalWidget(cal, cfg = {}) {
  return `<div role="button" tabindex="0" class="gr-cal gr-paper" data-sl-cal="open" data-tooltip="Open calendar">
      <span class="gr-cal-day"><small>${esc(String(cal.monthName).slice(0, 3))}</small><b>${esc(cal.day)}</b></span>
      <span class="gr-cal-text">
        <span class="gr-cal-main">${esc(cal.weekday)}, ${esc(cal.day)} ${esc(cal.monthName)}</span>
        <span class="gr-cal-sub">${esc(cal.year)} ${esc(cal.era)}${cfg.showTime !== false ? ` · ${pad(cal.hour)}:${pad(cal.minute)}` : ""}${cal.season ? ` · ${esc(cal.season)}` : ""}${cal.moon ? ` · ${esc(cal.moon)}` : ""}</span>
      </span>
      <i class="fa-solid fa-moon gr-cal-moon"></i>
    </div>`;
}

export { fmtTime };

/** Full month view shown when the calendar widget is clicked. */
export function renderCalendarModal(cal, cfg, isGM) {
  const wd = cal.weekdays || [];
  const cells = [];
  for (let i = 0; i < cal.firstWeekdayIndex; i++) cells.push(`<span class="blank"></span>`);
  for (let day = 1; day <= cal.monthDays; day++) cells.push(`<span class="${day === cal.day ? "today" : ""}">${day}</span>`);
  const canAdvance = isGM && cfg.source !== "manual" && cfg.gmControls !== false;
  return `<div class="sl-modal gr-cal-modal" role="dialog">
    <header><h2>${esc(cal.monthName)} <small>${esc(cal.year)} ${esc(cal.era)}</small></h2><div role="button" tabindex="0" data-sl-close aria-label="Close">✕</div></header>
    <div class="sl-modal-body">
      <p class="gr-cal-line">${esc(cal.weekday)}, day ${esc(cal.day)} · ${pad(cal.hour)}:${pad(cal.minute)}${cal.season ? ` · ${esc(cal.season)}` : ""}${cal.moon ? ` · ${esc(cal.moon)}` : ""}</p>
      <div class="gr-grid" style="--wd:${Math.max(1, wd.length)}">
        ${wd.map((w) => `<b title="${esc(w)}">${esc(w.length > 4 ? w.slice(0, 3) : w)}</b>`).join("")}
        ${cells.join("")}
      </div>
      ${canAdvance ? `<div class="gr-advance">
        <div role="button" tabindex="0" data-sl-time="-3600">−1 hour</div>
        <div role="button" tabindex="0" data-sl-time="3600">+1 hour</div>
        <div role="button" tabindex="0" data-sl-time="28800">+8 hours (long rest)</div>
        <div role="button" tabindex="0" data-sl-time="86400">+1 day</div>
      </div>` : ""}
    </div>
  </div>`;
}
