/**
 * Interactive World Map.
 *
 * A full-screen viewer (above the lobby, below Foundry windows) showing a map image with
 * color-coded zones drawn on it. Clicking a zone flies the camera into it, spotlights it and
 * reveals that zone's waymarks; waymarks run the same actions as lobby buttons (journals,
 * pages, scenes, pop-up notes…). The GM draws zones and places waymarks right on the map.
 *
 * Coordinates are stored normalized (0–1) to the image, so swapping in a higher-resolution
 * copy of the same map keeps everything lined up.
 */
import { MODULE_ID, ACTION_TYPES, blankAction } from "./defaults.js";
import { esc } from "./render.js";
import { Lobby } from "./lobby.js";
import { RELATIONSHIP_VIEWS } from "./integrations.js";

const { deepClone, randomID, debounce } = foundry.utils;

export const ZONE_COLORS = ["#e05a4a", "#e8a33d", "#e6d84c", "#6cc06a", "#3aa6a0", "#4a8fe0", "#8a6ae0", "#d465b5", "#9a7b55", "#7f8c99"];
export const PIN_ICONS = {
  "fa-solid fa-location-dot": "Marker",
  "fa-solid fa-flag": "Flag",
  "fa-solid fa-star": "Star",
  "fa-solid fa-house": "Town",
  "fa-solid fa-chess-rook": "Castle",
  "fa-solid fa-landmark": "Landmark",
  "fa-solid fa-dungeon": "Dungeon",
  "fa-solid fa-mountain": "Mountain",
  "fa-solid fa-tree": "Forest",
  "fa-solid fa-water": "Water",
  "fa-solid fa-anchor": "Port",
  "fa-solid fa-campground": "Camp",
  "fa-solid fa-skull": "Danger",
  "fa-solid fa-dragon": "Dragon",
  "fa-solid fa-crown": "Royal",
  "fa-solid fa-scroll": "Quest",
  "fa-solid fa-question": "Unknown"
};

export function defaultMap() {
  return { title: "World Map", image: "", fillOpacity: 0.28, showLabels: true, zones: [], pins: [] };
}

const MIN_DRAG = 4;              // px before a press counts as a drag
const ZOOM_MAX = 10;             // × the fit-to-screen scale
const ZONE_PAD = 0.18;           // breathing room around a focused zone

/* ---------------------------------------------------------------------- */
/*  Geometry helpers                                                       */
/* ---------------------------------------------------------------------- */

function bbox(points) {
  const xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
  return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
}

/** Area-weighted centroid (falls back to the vertex average for degenerate shapes). */
function centroid(points) {
  let a = 0, cx = 0, cy = 0;
  for (let i = 0; i < points.length; i++) {
    const [x0, y0] = points[i], [x1, y1] = points[(i + 1) % points.length];
    const f = x0 * y1 - x1 * y0;
    a += f; cx += (x0 + x1) * f; cy += (y0 + y1) * f;
  }
  if (Math.abs(a) < 1e-9) return points.reduce((s, p) => [s[0] + p[0] / points.length, s[1] + p[1] / points.length], [0, 0]);
  return [cx / (3 * a), cy / (3 * a)];
}

function inside(pt, poly) {
  let ok = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > pt[1]) !== (yj > pt[1]) && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) ok = !ok;
  }
  return ok;
}

const clamp01 = (v) => Math.min(1, Math.max(0, v));

/* ====================================================================== */

export class WorldMap {
  static el = null;
  static data = defaultMap();
  static W = 0;            // natural image size
  static H = 0;
  static view = { x: 0, y: 0, s: 1 };
  static fitS = 1;
  static focus = null;     // focused zone id
  static edit = false;
  static tool = "select";  // select | poly | rect | pin
  static sel = null;       // { type: "zone"|"pin", id }
  static draft = [];       // polygon being drawn
  static #press = null;
  static #saveSoon = null;

  /* ------------------------------------------------------------------ */
  /*  Open / close                                                        */
  /* ------------------------------------------------------------------ */

  static async open({ zone } = {}) {
    this.load();
    if (!this.el) {
      this.el = document.createElement("div");
      this.el.id = "sl-map";
      document.body.appendChild(this.el);
      this.#bindGlobal();
      // Listeners on the outer element are attached once; render() only replaces its contents.
      this.el.addEventListener("click", (ev) => this.#onClick(ev));
      this.el.addEventListener("keydown", (ev) => {
        if ((ev.key === "Enter" || ev.key === " ") && ev.target.matches?.('[role="button"]')) { ev.preventDefault(); ev.target.click(); }
      });
    }
    this.focus = zone ?? null;
    this.view = { x: 0, y: 0, s: 0 }; // force a fresh fit
    await this.#loadImage();
    this.render();
    if (zone) this.zoomToZone(zone, false);
  }

  static close() {
    if (!this.el) return;
    if (this.edit) this.#flushSave();
    this.el.classList.add("slm-leaving");
    const el = this.el;
    this.el = null;
    this.edit = false;
    this.sel = null;
    this.draft = [];
    window.removeEventListener("keydown", this.#onKey, true);
    window.removeEventListener("resize", this.#onResize);
    setTimeout(() => el.remove(), 250);
  }

  static load() {
    const saved = game.settings.get(MODULE_ID, "worldMap") ?? {};
    this.data = { ...defaultMap(), ...deepClone(saved) };
    this.data.zones ??= [];
    this.data.pins ??= [];
  }

  /** Setting changed (someone saved). Players and non-editing GMs follow along. */
  static onSettingChange() {
    if (!this.el || this.edit) return;
    const oldImg = this.data.image;
    this.load();
    if (this.data.image !== oldImg) this.#loadImage().then(() => this.render());
    else this.render();
  }

  static async #loadImage() {
    const src = this.data.image;
    if (!src) { this.W = this.H = 0; return; }
    await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => { this.W = img.naturalWidth; this.H = img.naturalHeight; resolve(); };
      img.onerror = () => { this.W = this.H = 0; resolve(); };
      img.src = src;
    });
  }

  static #bindGlobal() {
    window.addEventListener("keydown", this.#onKey, true);
    window.addEventListener("resize", this.#onResize);
  }

  static #onKey = (ev) => {
    if (!this.el) return;
    if (ev.target.closest?.("input, textarea, select")) {
      if (ev.key === "Escape") ev.target.blur();
      return;
    }
    if (ev.key === "Escape") {
      ev.preventDefault();
      ev.stopPropagation();
      if (this.el.querySelector(".slm-note")) return this.#closeNote();
      if (this.draft.length) { this.draft = []; return this.#renderStage(); }
      if (this.sel && this.edit) { this.sel = null; return this.render(); }
      if (this.focus) return this.zoomOut();
      return this.close();
    }
    if (ev.key === "Enter" && this.tool === "poly" && this.draft.length >= 3) {
      ev.preventDefault();
      ev.stopPropagation();
      this.#finishPolygon();
    }
  };

  static #onResize = debounce(() => {
    if (!this.el) return;
    this.#computeFit();
    if (this.focus) this.zoomToZone(this.focus, false);
    else this.resetView(false);
  }, 100);

  /* ------------------------------------------------------------------ */
  /*  Visibility                                                          */
  /* ------------------------------------------------------------------ */

  static get zones() {
    return this.data.zones.filter((z) => game.user.isGM || !z.hidden);
  }

  static pinsFor(zoneId) {
    return this.data.pins.filter((p) => (game.user.isGM || !p.hidden) && (p.zoneId ?? null) === (zoneId ?? null));
  }

  static zone(id) {
    return this.data.zones.find((z) => z.id === id);
  }

  /* ------------------------------------------------------------------ */
  /*  Camera                                                              */
  /* ------------------------------------------------------------------ */

  static get viewport() { return this.el?.querySelector(".slm-viewport"); }

  static #computeFit() {
    const vp = this.viewport;
    if (!vp || !this.W) return;
    this.fitS = Math.min(vp.clientWidth / this.W, vp.clientHeight / this.H);
  }

  static resetView(animate = true) {
    const vp = this.viewport;
    if (!vp || !this.W) return;
    this.#computeFit();
    const s = this.fitS;
    this.setView({ s, x: (vp.clientWidth - this.W * s) / 2, y: (vp.clientHeight - this.H * s) / 2 }, animate);
  }

  static setView(v, animate = true) {
    this.view = v;
    const stage = this.el?.querySelector(".slm-stage");
    if (!stage) return;
    stage.classList.toggle("animating", animate);
    stage.style.transform = `translate(${v.x}px, ${v.y}px) scale(${v.s})`;
    stage.style.setProperty("--inv", 1 / v.s);
    if (animate) setTimeout(() => stage.classList.remove("animating"), 650);
  }

  static zoomToZone(id, animate = true) {
    const z = this.zone(id);
    const vp = this.viewport;
    if (!z || !vp || !this.W) return;
    this.#computeFit();
    const b = bbox(z.points);
    const bw = Math.max(0.01, b.x1 - b.x0) * this.W, bh = Math.max(0.01, b.y1 - b.y0) * this.H;
    const cx = ((b.x0 + b.x1) / 2) * this.W, cy = ((b.y0 + b.y1) / 2) * this.H;
    const s = Math.min(vp.clientWidth / (bw * (1 + ZONE_PAD * 2)), vp.clientHeight / (bh * (1 + ZONE_PAD * 2)), this.fitS * ZOOM_MAX);
    this.setView({ s, x: vp.clientWidth / 2 - cx * s, y: vp.clientHeight / 2 - cy * s }, animate);
  }

  static focusZone(id) {
    this.focus = id;
    if (this.edit) this.sel = { type: "zone", id };
    this.render();
    this.zoomToZone(id);
  }

  static zoomOut() {
    this.focus = null;
    this.render();
    this.resetView();
  }

  /** Screen (client) point → normalized image coords. */
  static toMap(clientX, clientY) {
    const r = this.viewport.getBoundingClientRect();
    const { x, y, s } = this.view;
    return [clamp01((clientX - r.left - x) / s / this.W), clamp01((clientY - r.top - y) / s / this.H)];
  }

  /* ------------------------------------------------------------------ */
  /*  Rendering                                                           */
  /* ------------------------------------------------------------------ */

  static render() {
    if (!this.el) return;
    const d = this.data;
    const gm = game.user.isGM;
    const z = this.focus ? this.zone(this.focus) : null;

    this.el.className = `${this.edit ? "slm-editing" : ""} slm-tool-${this.tool}`;
    this.el.innerHTML = `
      <div class="slm-frame">
        <header class="slm-head">
          <span class="slm-crumbs">
            <span role="button" tabindex="0" class="slm-crumb ${z ? "link" : ""}" data-slm="world"><i class="fa-solid fa-earth-americas"></i> ${esc(d.title)}</span>
            ${z ? `<i class="fa-solid fa-chevron-right slm-sep"></i><span class="slm-crumb"><i class="slm-dot" style="background:${esc(z.color)}"></i>${esc(z.name)}</span>` : ""}
          </span>
          <span class="slm-head-tools">
            ${z ? `<span role="button" tabindex="0" data-slm="back" class="slm-btn"><i class="fa-solid fa-magnifying-glass-minus"></i> Whole map</span>` : ""}
            ${gm ? `<span role="button" tabindex="0" data-slm="edit" class="slm-btn ${this.edit ? "on" : ""}"><i class="fa-solid fa-pen-ruler"></i> ${this.edit ? "Done editing" : "Edit map"}</span>` : ""}
            <span role="button" tabindex="0" data-slm="close" class="slm-btn slm-close" aria-label="Close">✕</span>
          </span>
        </header>
        <div class="slm-body">
          <div class="slm-viewport">
            ${this.W ? `<div class="slm-stage" style="width:${this.W}px;height:${this.H}px">
              <img class="slm-img" src="${esc(d.image)}" alt="" draggable="false">
              <svg class="slm-svg" viewBox="0 0 ${this.W} ${this.H}" preserveAspectRatio="none"></svg>
              <div class="slm-layer"></div>
            </div>` : this.#emptyState()}
            ${this.edit ? this.#toolbar() : ""}
            <div class="slm-zoom">
              <span role="button" tabindex="0" data-slm="zin" aria-label="Zoom in">+</span>
              <span role="button" tabindex="0" data-slm="zout" aria-label="Zoom out">−</span>
            </div>
          </div>
          <aside class="slm-side">${this.edit ? this.#editPanel() : this.#viewPanel()}</aside>
        </div>
        <div class="slm-note-root"></div>
      </div>`;

    this.#bindLocal();
    if (this.W) {
      this.#renderStage();
      this.#computeFit();
      // Restore the camera without animating (render replaces the stage element).
      if (!this.view.s) this.resetView(false);
      else this.setView(this.view, false);
    }
    if (!this.edit && z) this.#enrichZoneDescription(z);
  }

  static #emptyState() {
    if (game.user.isGM) return `<div class="slm-empty"><i class="fa-solid fa-map"></i>
      <p>No map image yet.</p><span role="button" tabindex="0" class="slm-btn" data-slm="pickImage"><i class="fa-solid fa-image"></i> Choose map image</span></div>`;
    return `<div class="slm-empty"><i class="fa-solid fa-map"></i><p>The world map hasn't been drawn yet.</p></div>`;
  }

  /** SVG zones + HTML pins/labels/handles (cheap to redo while dragging). */
  static #renderStage() {
    const svg = this.el?.querySelector(".slm-svg");
    const layer = this.el?.querySelector(".slm-layer");
    if (!svg || !layer) return;
    const d = this.data, W = this.W, H = this.H, gm = game.user.isGM;
    const pts = (poly) => poly.map((p) => `${p[0] * W},${p[1] * H}`).join(" ");
    const op = Number(d.fillOpacity ?? 0.28);

    let s = "";
    for (const zn of this.zones) {
      const focused = zn.id === this.focus;
      const selected = this.sel?.type === "zone" && this.sel.id === zn.id;
      s += `<polygon class="slm-zone${focused ? " focused" : ""}${selected ? " selected" : ""}${zn.hidden ? " hidden-zone" : ""}"
        data-zone="${esc(zn.id)}" points="${pts(zn.points)}"
        style="--zc:${esc(zn.color)};--zo:${focused ? 0.06 : op}" vector-effect="non-scaling-stroke"><title>${esc(zn.name)}</title></polygon>`;
    }
    // Spotlight: darken everything outside the focused zone.
    const fz = this.focus ? this.zone(this.focus) : null;
    if (fz) {
      const hole = fz.points.map((p, i) => `${i ? "L" : "M"}${p[0] * W} ${p[1] * H}`).join(" ") + " Z";
      s += `<path class="slm-spot" fill-rule="evenodd" d="M0 0 H${W} V${H} H0 Z ${hole}"/>`;
    }
    if (this.draft.length) {
      s += `<polyline class="slm-draft" points="${pts(this.draft)}" vector-effect="non-scaling-stroke"/>`;
    }
    svg.innerHTML = s;

    // Labels, pins and editing handles live in an HTML layer so they stay a constant size.
    let h = "";
    if (d.showLabels !== false) {
      for (const zn of this.zones) {
        if (zn.id === this.focus) continue;
        const [cx, cy] = centroid(zn.points);
        h += `<span class="slm-zlabel${this.focus ? " dim" : ""}" style="left:${cx * 100}%;top:${cy * 100}%;--zc:${esc(zn.color)}" data-zone="${esc(zn.id)}">${esc(zn.name)}</span>`;
      }
    }
    const visiblePins = [...this.pinsFor(null), ...(this.focus ? this.pinsFor(this.focus) : [])];
    if (this.edit) {
      // Editing: show every pin so they can be moved (zone pins faded when not focused).
      for (const p of d.pins) if (!visiblePins.includes(p)) visiblePins.push(p);
    }
    for (const p of visiblePins) {
      const sel = this.sel?.type === "pin" && this.sel.id === p.id;
      const away = p.zoneId && p.zoneId !== this.focus;
      h += `<div role="button" tabindex="0" class="slm-pin${sel ? " selected" : ""}${p.hidden ? " hidden-pin" : ""}${away ? " away" : ""}${p.alwaysLabel === false ? "" : " labelled"}"
        data-pin="${esc(p.id)}" style="left:${p.x * 100}%;top:${p.y * 100}%;--pc:${esc(p.color || "#c9a45c")}" data-tooltip="${esc(p.label)}">
        <span class="slm-pin-head"><i class="${esc(p.icon || "fa-solid fa-location-dot")}"></i></span>
        ${p.label ? `<span class="slm-pin-label">${esc(p.label)}</span>` : ""}
      </div>`;
    }
    if (this.edit && this.sel?.type === "zone" && this.tool === "select") {
      const zn = this.zone(this.sel.id);
      zn?.points.forEach((pt, i) => {
        h += `<span class="slm-handle" data-vertex="${i}" style="left:${pt[0] * 100}%;top:${pt[1] * 100}%" data-tooltip="Drag to move · right-click to delete"></span>`;
      });
    }
    if (this.draft.length) {
      const [x, y] = this.draft[0];
      h += `<span class="slm-handle first" style="left:${x * 100}%;top:${y * 100}%"></span>`;
    }
    layer.innerHTML = h;
  }

  static #viewPanel() {
    const z = this.focus ? this.zone(this.focus) : null;
    if (z) {
      const pins = this.pinsFor(z.id);
      return `<div class="slm-panel">
        <h2><i class="slm-dot big" style="background:${esc(z.color)}"></i>${esc(z.name)}</h2>
        <div class="slm-desc" data-slm-desc>${z.description ? "…" : ""}</div>
        <h3>Places</h3>
        <div class="slm-places">${pins.map((p) => `
          <div role="button" tabindex="0" class="slm-place" data-pin="${esc(p.id)}" style="--pc:${esc(p.color || "#c9a45c")}">
            <span class="slm-place-ico"><i class="${esc(p.icon)}"></i></span><span>${esc(p.label || "Unnamed")}</span>
            ${p.action?.type && p.action.type !== "none" ? `<i class="fa-solid fa-arrow-right slm-go"></i>` : ""}
          </div>`).join("") || `<p class="slm-muted">Nothing marked here yet.</p>`}</div>
        <div role="button" tabindex="0" class="slm-btn wide" data-slm="back"><i class="fa-solid fa-arrow-left"></i> Back to the whole map</div>
      </div>`;
    }
    const zones = this.zones;
    const world = this.pinsFor(null);
    return `<div class="slm-panel">
      <h2>${esc(this.data.title)}</h2>
      <p class="slm-muted">Click a region to explore it.</p>
      <h3>Regions</h3>
      <div class="slm-legend">${zones.map((zn) => `
        <div role="button" tabindex="0" class="slm-legend-row" data-zone="${esc(zn.id)}">
          <i class="slm-dot" style="background:${esc(zn.color)}"></i><span>${esc(zn.name)}</span>
          <small>${this.pinsFor(zn.id).length || ""}</small>
        </div>`).join("") || `<p class="slm-muted">No regions yet.</p>`}</div>
      ${world.length ? `<h3>Landmarks</h3><div class="slm-places">${world.map((p) => `
        <div role="button" tabindex="0" class="slm-place" data-pin="${esc(p.id)}" style="--pc:${esc(p.color || "#c9a45c")}">
          <span class="slm-place-ico"><i class="${esc(p.icon)}"></i></span><span>${esc(p.label || "Unnamed")}</span>
        </div>`).join("")}</div>` : ""}
    </div>`;
  }

  static async #enrichZoneDescription(z) {
    const box = this.el?.querySelector("[data-slm-desc]");
    if (!box || !z.description) return;
    const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
    box.innerHTML = await TE.enrichHTML(z.description, { secrets: game.user.isGM });
  }

  /* ------------------------------------------------------------------ */
  /*  Pins & notes                                                        */
  /* ------------------------------------------------------------------ */

  static async activatePin(id) {
    const p = this.data.pins.find((x) => x.id === id);
    if (!p) return;
    const a = p.action ?? blankAction();
    if (a.type === "text") return this.#showNote(a.title || p.label, a.content);
    if (!a.type || a.type === "none") return;
    if (a.type === "map") return; // already here
    return Lobby.runAction(a, p.label);
  }

  static async #showNote(title, content) {
    const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
    const html = await TE.enrichHTML(content || "", { secrets: game.user.isGM });
    const root = this.el?.querySelector(".slm-note-root");
    if (!root) return;
    root.innerHTML = `<div class="slm-note"><div class="slm-note-card">
      <header><h2>${esc(title)}</h2><span role="button" tabindex="0" data-slm="noteClose" class="slm-close">✕</span></header>
      <div class="slm-note-body">${html}</div></div></div>`;
  }

  static #closeNote() {
    const root = this.el?.querySelector(".slm-note-root");
    if (root) root.innerHTML = "";
  }

  /* ------------------------------------------------------------------ */
  /*  Pointer handling                                                    */
  /* ------------------------------------------------------------------ */

  static #bindLocal() {
    const el = this.el;
    const vp = this.viewport;
    if (!vp) return;
    vp.addEventListener("pointerdown", (ev) => this.#onDown(ev));
    vp.addEventListener("pointermove", (ev) => this.#onMove(ev));
    vp.addEventListener("pointerup", (ev) => this.#onUp(ev));
    vp.addEventListener("pointercancel", () => { this.#press = null; });
    vp.addEventListener("wheel", (ev) => this.#onWheel(ev), { passive: false });
    vp.addEventListener("dblclick", (ev) => {
      if (this.tool === "poly" && this.draft.length >= 3) return this.#finishPolygon();
      const zid = ev.target.closest("[data-zone]")?.dataset.zone;
      if (zid && this.edit) this.focusZone(zid);
    });
    vp.addEventListener("contextmenu", (ev) => {
      const h = ev.target.closest("[data-vertex]");
      if (!h || !this.edit) return;
      ev.preventDefault();
      const zn = this.zone(this.sel?.id);
      if (zn && zn.points.length > 3) {
        zn.points.splice(Number(h.dataset.vertex), 1);
        this.#changed();
        this.#renderStage();
      }
    });
    // Drop journals/scenes etc. onto the side panel action box.
    for (const box of el.querySelectorAll("[data-slm-drop]")) {
      box.addEventListener("dragover", (ev) => { ev.preventDefault(); box.classList.add("over"); });
      box.addEventListener("dragleave", () => box.classList.remove("over"));
      box.addEventListener("drop", (ev) => this.#onDropAction(ev, box));
    }
    // Edit panel inputs.
    for (const inp of el.querySelectorAll("[data-slm-field]")) {
      const evName = inp.type === "checkbox" || inp.tagName === "SELECT" ? "change" : "input";
      inp.addEventListener(evName, () => this.#onField(inp));
    }
  }

  static #onDown(ev) {
    if (ev.button !== 0) return;
    if (ev.target.closest(".slm-zoom, .slm-toolbar")) return;
    const vp = this.viewport;
    const handle = ev.target.closest("[data-vertex]");
    const pin = ev.target.closest(".slm-pin");
    this.#press = {
      x: ev.clientX, y: ev.clientY, moved: false, target: ev.target,
      view: { ...this.view },
      vertex: this.edit && this.tool === "select" && handle ? Number(handle.dataset.vertex) : null,
      pin: this.edit && this.tool === "select" && pin ? pin.dataset.pin : null,
      rect: this.edit && this.tool === "rect" && this.W ? this.toMap(ev.clientX, ev.clientY) : null
    };
    vp.setPointerCapture?.(ev.pointerId);
  }

  static #onMove(ev) {
    const p = this.#press;
    if (!p) return;
    const dx = ev.clientX - p.x, dy = ev.clientY - p.y;
    if (!p.moved && Math.hypot(dx, dy) < MIN_DRAG) return;
    p.moved = true;
    if (p.vertex !== null) {
      const zn = this.zone(this.sel?.id);
      if (zn) { zn.points[p.vertex] = this.toMap(ev.clientX, ev.clientY); this.#renderStage(); }
      return;
    }
    if (p.pin) {
      const pin = this.data.pins.find((x) => x.id === p.pin);
      if (pin) { [pin.x, pin.y] = this.toMap(ev.clientX, ev.clientY); this.#renderStage(); }
      return;
    }
    if (p.rect) {
      const [x1, y1] = this.toMap(ev.clientX, ev.clientY);
      const [x0, y0] = p.rect;
      this.draft = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
      this.#renderStage();
      return;
    }
    // Pan.
    this.setView({ ...p.view, x: p.view.x + dx, y: p.view.y + dy }, false);
    this.viewport.classList.add("panning");
  }

  static #onUp(ev) {
    const p = this.#press;
    this.#press = null;
    this.viewport?.classList.remove("panning");
    if (!p) return;
    if (p.moved) {
      if (p.vertex !== null || p.pin) { this.#changed(); this.render(); }
      if (p.rect) {
        const b = bbox(this.draft);
        if (b.x1 - b.x0 > 0.005 && b.y1 - b.y0 > 0.005) this.#createZone(this.draft);
        this.draft = [];
        this.#renderStage();
      }
      return;
    }
    this.#onMapClick(ev, p.target);
  }

  /** A click (not a drag) on the map surface. */
  static #onMapClick(ev, target) {
    if (!this.W) return;
    const pt = this.toMap(ev.clientX, ev.clientY);
    const pinEl = target.closest?.(".slm-pin");
    const zoneEl = target.closest?.("[data-zone]");

    if (this.edit) {
      if (this.tool === "poly") {
        if (this.draft.length >= 3 && target.closest?.(".slm-handle.first")) return this.#finishPolygon();
        this.draft.push(pt);
        return this.#renderStage();
      }
      if (this.tool === "pin") return this.#createPin(pt);
      if (this.tool === "select") {
        if (pinEl) { this.sel = { type: "pin", id: pinEl.dataset.pin }; return this.render(); }
        if (zoneEl) { this.sel = { type: "zone", id: zoneEl.dataset.zone }; return this.render(); }
        if (this.sel) { this.sel = null; return this.render(); }
      }
      return;
    }

    if (pinEl) return this.activatePin(pinEl.dataset.pin);
    if (zoneEl && zoneEl.dataset.zone !== this.focus) return this.focusZone(zoneEl.dataset.zone);
  }

  static #onWheel(ev) {
    if (!this.W) return;
    ev.preventDefault();
    const r = this.viewport.getBoundingClientRect();
    const mx = ev.clientX - r.left, my = ev.clientY - r.top;
    const { x, y, s } = this.view;
    const factor = Math.exp(-ev.deltaY * 0.0015);
    const ns = Math.min(this.fitS * ZOOM_MAX, Math.max(this.fitS * 0.6, s * factor));
    this.setView({ s: ns, x: mx - (mx - x) * (ns / s), y: my - (my - y) * (ns / s) }, false);
  }

  static #zoomBy(f) {
    const vp = this.viewport;
    if (!vp || !this.W) return;
    const mx = vp.clientWidth / 2, my = vp.clientHeight / 2;
    const { x, y, s } = this.view;
    const ns = Math.min(this.fitS * ZOOM_MAX, Math.max(this.fitS * 0.6, s * f));
    this.setView({ s: ns, x: mx - (mx - x) * (ns / s), y: my - (my - y) * (ns / s) });
  }

  /* ------------------------------------------------------------------ */
  /*  Clicks on chrome (header, side panel, toolbar)                      */
  /* ------------------------------------------------------------------ */

  static async #onClick(ev) {
    const t = ev.target;
    const cmd = t.closest("[data-slm]")?.dataset.slm;
    if (cmd) return this.#onCommand(cmd, t.closest("[data-slm]"));
    if (t.closest(".slm-viewport")) return; // handled by pointer events
    const place = t.closest(".slm-place[data-pin]");
    if (place) {
      if (this.edit) { this.sel = { type: "pin", id: place.dataset.pin }; return this.render(); }
      return this.activatePin(place.dataset.pin);
    }
    const row = t.closest(".slm-legend-row[data-zone], .slm-zone-row[data-zone]");
    if (row) return this.focusZone(row.dataset.zone);
    if (t.classList?.contains("slm-note")) return this.#closeNote();
  }

  static async #onCommand(cmd, el) {
    switch (cmd) {
      case "close": return this.close();
      case "world": case "back": return this.focus ? this.zoomOut() : null;
      case "zin": return this.#zoomBy(1.4);
      case "zout": return this.#zoomBy(1 / 1.4);
      case "noteClose": return this.#closeNote();
      case "edit":
        if (!game.user.isGM) return;
        if (this.edit) this.#flushSave();
        this.edit = !this.edit;
        this.tool = "select";
        this.sel = null;
        this.draft = [];
        return this.render();
      case "tool":
        this.tool = el.dataset.tool;
        this.draft = [];
        return this.render();
      case "pickImage": return this.#pickImage();
      case "deleteSel": return this.#deleteSelected();
      case "zoomSel":
        if (this.sel?.type === "zone") return this.focusZone(this.sel.id);
        return;
      case "deselect":
        this.sel = null;
        return this.render();
      case "color": {
        const zn = this.zone(this.sel?.id);
        if (zn) { zn.color = el.dataset.color; this.#changed(); this.render(); }
        return;
      }
      case "testPin":
        if (this.sel?.type === "pin") return this.activatePin(this.sel.id);
        return;
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Editing                                                             */
  /* ------------------------------------------------------------------ */

  static #toolbar() {
    const tool = (id, icon, label) => `<span role="button" tabindex="0" class="slm-tool ${this.tool === id ? "on" : ""}" data-slm="tool" data-tool="${id}" data-tooltip="${label}"><i class="${icon}"></i><b>${label}</b></span>`;
    const hint = {
      select: "Click a region or waymark to edit it. Drag waymarks and corner handles to move them.",
      poly: "Click to place corners. Click the first corner, double-click or press Enter to finish. Esc cancels.",
      rect: "Drag a box to make a rectangular region.",
      pin: this.focus ? "Click to place a waymark in this region." : "Click to place a landmark on the whole map (zoom into a region first to place a waymark inside it)."
    }[this.tool];
    return `<div class="slm-toolbar">
      ${tool("select", "fa-solid fa-arrow-pointer", "Select")}
      ${tool("poly", "fa-solid fa-draw-polygon", "Draw region")}
      ${tool("rect", "fa-regular fa-square", "Box region")}
      ${tool("pin", "fa-solid fa-location-dot", "Waymark")}
      <span class="slm-tool-hint">${hint}</span>
    </div>`;
  }

  static #editPanel() {
    const d = this.data;
    if (this.sel?.type === "zone") {
      const z = this.zone(this.sel.id);
      if (z) return `<div class="slm-panel slm-edit">
        <h2>Region</h2>
        <label>Name<input type="text" data-slm-field="zone.name" value="${esc(z.name)}"></label>
        <label>Color</label>
        <div class="slm-swatches">${ZONE_COLORS.map((c) => `<span role="button" tabindex="0" class="slm-swatch ${c === z.color ? "on" : ""}" style="background:${c}" data-slm="color" data-color="${c}"></span>`).join("")}
          <input type="color" data-slm-field="zone.color" value="${esc(/^#[0-9a-f]{6}$/i.test(z.color) ? z.color : "#e05a4a")}" title="Custom color"></div>
        <label>Description <small>(shown when players open the region; @UUID links work)</small>
          <textarea data-slm-field="zone.description" rows="5">${esc(z.description || "")}</textarea></label>
        <label class="check"><input type="checkbox" data-slm-field="zone.hidden" ${z.hidden ? "checked" : ""}> Hidden from players</label>
        <h3>Waymarks in this region</h3>
        <div class="slm-places">${this.data.pins.filter((p) => p.zoneId === z.id).map((p) => `
          <div role="button" tabindex="0" class="slm-place" data-pin="${esc(p.id)}" style="--pc:${esc(p.color)}">
            <span class="slm-place-ico"><i class="${esc(p.icon)}"></i></span><span>${esc(p.label || "Unnamed")}</span></div>`).join("")
          || `<p class="slm-muted">Zoom in and use the Waymark tool to add some.</p>`}</div>
        <div class="slm-row">
          <span role="button" tabindex="0" class="slm-btn" data-slm="zoomSel"><i class="fa-solid fa-magnifying-glass-plus"></i> Zoom in</span>
          <span role="button" tabindex="0" class="slm-btn danger" data-slm="deleteSel"><i class="fa-solid fa-trash"></i> Delete</span>
        </div>
        <span role="button" tabindex="0" class="slm-btn wide ghost" data-slm="deselect">Map settings</span>
      </div>`;
    }
    if (this.sel?.type === "pin") {
      const p = this.data.pins.find((x) => x.id === this.sel.id);
      if (p) {
        const a = p.action ?? (p.action = blankAction());
        const types = Object.fromEntries(Object.entries(ACTION_TYPES).filter(([k]) => !["live", "map"].includes(k)));
        return `<div class="slm-panel slm-edit">
          <h2>Waymark</h2>
          <label>Label<input type="text" data-slm-field="pin.label" value="${esc(p.label)}"></label>
          <label>Icon<select data-slm-field="pin.icon">${Object.entries(PIN_ICONS).map(([k, v]) => `<option value="${k}" ${k === p.icon ? "selected" : ""}>${v}</option>`).join("")}</select></label>
          <label>Color<input type="color" data-slm-field="pin.color" value="${esc(p.color || "#c9a45c")}"></label>
          <label>Shown in<select data-slm-field="pin.zoneId">
            <option value="">The whole map (landmark)</option>
            ${this.data.zones.map((z) => `<option value="${esc(z.id)}" ${z.id === p.zoneId ? "selected" : ""}>${esc(z.name)} (when zoomed in)</option>`).join("")}
          </select></label>
          <label class="check"><input type="checkbox" data-slm-field="pin.alwaysLabel" ${p.alwaysLabel !== false ? "checked" : ""}> Always show label</label>
          <label class="check"><input type="checkbox" data-slm-field="pin.hidden" ${p.hidden ? "checked" : ""}> Hidden from players</label>
          <div class="slm-action" data-slm-drop>
            <label>When clicked<select data-slm-field="pin.action.type">${Object.entries(types).map(([k, v]) => `<option value="${k}" ${k === a.type ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
            ${["journal", "actor", "item", "macro", "scene", "shop"].includes(a.type) ? `<label>Linked document
              <input type="text" data-slm-field="pin.action.uuid" value="${esc(a.uuid)}" placeholder="Drag a ${a.type} onto this box"></label>` : ""}
            ${a.type === "relationships" ? `<label>Opens<select data-slm-field="pin.action.view">${Object.entries(RELATIONSHIP_VIEWS).map(([k, v]) => `<option value="${k}" ${k === (a.view || "picker") ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
              ${a.view === "actor" ? `<label>Character<input type="text" data-slm-field="pin.action.uuid" value="${esc(a.uuid)}" placeholder="Drag an Actor onto this box"></label>` : ""}` : ""}
            ${a.type === "url" ? `<label>Web address<input type="text" data-slm-field="pin.action.url" value="${esc(a.url)}"></label>` : ""}
            ${a.type === "text" ? `<label>Note title<input type="text" data-slm-field="pin.action.title" value="${esc(a.title)}"></label>
              <label>Note text<textarea rows="5" data-slm-field="pin.action.content">${esc(a.content)}</textarea></label>` : ""}
          </div>
          <div class="slm-row">
            <span role="button" tabindex="0" class="slm-btn" data-slm="testPin"><i class="fa-solid fa-play"></i> Test</span>
            <span role="button" tabindex="0" class="slm-btn danger" data-slm="deleteSel"><i class="fa-solid fa-trash"></i> Delete</span>
          </div>
          <span role="button" tabindex="0" class="slm-btn wide ghost" data-slm="deselect">Map settings</span>
        </div>`;
      }
    }
    return `<div class="slm-panel slm-edit">
      <h2>Map settings</h2>
      <label>Title<input type="text" data-slm-field="map.title" value="${esc(d.title)}"></label>
      <label>Map image</label>
      <span role="button" tabindex="0" class="slm-btn wide" data-slm="pickImage"><i class="fa-solid fa-image"></i> ${d.image ? "Change image" : "Choose image"}</span>
      ${d.image ? `<p class="slm-muted slm-path">${esc(d.image)}</p>` : ""}
      <label>Region fill strength<input type="range" min="0" max="0.8" step="0.02" data-slm-field="map.fillOpacity" value="${Number(d.fillOpacity ?? 0.28)}"></label>
      <label class="check"><input type="checkbox" data-slm-field="map.showLabels" ${d.showLabels !== false ? "checked" : ""}> Show region names</label>
      <h3>Regions</h3>
      <div class="slm-legend">${d.zones.map((z) => `
        <div role="button" tabindex="0" class="slm-zone-row slm-legend-row" data-zone="${esc(z.id)}">
          <i class="slm-dot" style="background:${esc(z.color)}"></i><span>${esc(z.name)}</span>${z.hidden ? `<i class="fa-solid fa-eye-slash" data-tooltip="Hidden"></i>` : ""}
        </div>`).join("") || `<p class="slm-muted">Use <b>Draw region</b> or <b>Box region</b> to add one.</p>`}</div>
      <p class="slm-muted">Changes save automatically and appear for everyone when you click <b>Done editing</b>.</p>
    </div>`;
  }

  static #onField(inp) {
    const [kind, ...path] = inp.dataset.slmField.split(".");
    let target;
    if (kind === "map") target = this.data;
    else if (kind === "zone") target = this.zone(this.sel?.id);
    else if (kind === "pin") target = this.data.pins.find((x) => x.id === this.sel?.id);
    if (!target) return;
    let value = inp.type === "checkbox" ? inp.checked : inp.type === "range" ? Number(inp.value) : inp.value;
    if (kind === "pin" && path[0] === "zoneId") value = value || null;
    foundry.utils.setProperty(target, path.join("."), value);
    this.#changed();
    // Structural changes need a full re-render; text edits only redraw the map.
    if (inp.tagName === "SELECT" || inp.type === "checkbox" || path[0] === "color") this.render();
    else this.#renderStage();
  }

  static async #onDropAction(ev, box) {
    ev.preventDefault();
    box.classList.remove("over");
    let data;
    try { data = JSON.parse(ev.dataTransfer.getData("text/plain")); } catch { return; }
    const uuid = data.uuid ?? (data.type && data.id ? `${data.type}.${data.id}` : null);
    const doc = uuid ? await fromUuid(uuid) : null;
    const p = this.data.pins.find((x) => x.id === this.sel?.id);
    if (!doc || !p) return;
    const map = { JournalEntry: "journal", JournalEntryPage: "journal", Actor: "actor", Item: "item", Macro: "macro", Scene: "scene" };
    const keepShop = p.action?.type === "shop" && doc.documentName === "Actor";
    const keepRel = p.action?.type === "relationships" && doc.documentName === "Actor";
    if (keepRel) p.action = { ...p.action, view: "actor", uuid: doc.uuid };
    else p.action = { ...blankAction(keepShop ? "shop" : (map[doc.documentName] ?? "journal")), uuid: doc.uuid };
    if (!p.label || p.label === "New waymark") p.label = doc.name;
    this.#changed();
    this.render();
  }

  static #createZone(points) {
    const used = new Set(this.data.zones.map((z) => z.color));
    const color = ZONE_COLORS.find((c) => !used.has(c)) ?? ZONE_COLORS[this.data.zones.length % ZONE_COLORS.length];
    const z = { id: randomID(), name: `Region ${this.data.zones.length + 1}`, color, description: "", hidden: false, points: points.map((p) => [...p]) };
    this.data.zones.push(z);
    this.sel = { type: "zone", id: z.id };
    this.tool = "select";
    this.#changed();
    this.render();
    setTimeout(() => this.el?.querySelector('[data-slm-field="zone.name"]')?.select(), 30);
  }

  static #finishPolygon() {
    // Double-click adds the same corner twice; drop near-duplicates.
    const pts = this.draft.filter((p, i, a) => i === 0 || Math.hypot(p[0] - a[i - 1][0], p[1] - a[i - 1][1]) > 0.002);
    if (pts.length < 3) return;
    this.draft = [];
    this.#createZone(pts);
  }

  static #createPin(pt) {
    let zoneId = this.focus;
    if (!zoneId) zoneId = null; // world landmark
    const p = { id: randomID(), zoneId, x: pt[0], y: pt[1], label: "New waymark", icon: "fa-solid fa-location-dot",
      color: "#c9a45c", hidden: false, alwaysLabel: true, action: blankAction("journal") };
    this.data.pins.push(p);
    this.sel = { type: "pin", id: p.id };
    this.tool = "select";
    this.#changed();
    this.render();
    setTimeout(() => this.el?.querySelector('[data-slm-field="pin.label"]')?.select(), 30);
  }

  static async #deleteSelected() {
    const { DialogV2 } = foundry.applications.api;
    if (this.sel?.type === "zone") {
      const z = this.zone(this.sel.id);
      const n = this.data.pins.filter((p) => p.zoneId === z?.id).length;
      const ok = await DialogV2.confirm({ window: { title: "Delete region" },
        content: `<p>Delete <b>${esc(z?.name)}</b>${n ? ` and its ${n} waymark${n === 1 ? "" : "s"}` : ""}?</p>` });
      if (!ok) return;
      this.data.zones = this.data.zones.filter((x) => x.id !== z.id);
      this.data.pins = this.data.pins.filter((p) => p.zoneId !== z.id);
      if (this.focus === z.id) this.focus = null;
    } else if (this.sel?.type === "pin") {
      this.data.pins = this.data.pins.filter((p) => p.id !== this.sel.id);
    }
    this.sel = null;
    this.#changed();
    this.render();
    if (!this.focus) this.resetView();
  }

  static #pickImage() {
    const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
    new FP({
      type: "image",
      current: this.data.image || "",
      callback: async (path) => {
        this.data.image = path;
        this.#changed();
        await this.#loadImage();
        this.view = { x: 0, y: 0, s: 0 };
        this.render();
      }
    }).render(true);
  }

  static #changed() {
    if (!game.user.isGM) return;
    this.#saveSoon ??= debounce(() => game.settings.set(MODULE_ID, "worldMap", deepClone(this.data)), 600);
    this.#saveSoon();
  }

  static #flushSave() {
    if (game.user.isGM) game.settings.set(MODULE_ID, "worldMap", deepClone(this.data));
  }
}

export function registerMap() {
  game.settings.register(MODULE_ID, "worldMap", {
    scope: "world", config: false, type: Object, default: defaultMap(),
    onChange: () => WorldMap.onSettingChange()
  });
  game.keybindings.register(MODULE_ID, "openMap", {
    name: "Open the World Map",
    editable: [],
    onDown: () => { WorldMap.el ? WorldMap.close() : WorldMap.open(); return true; }
  });
}
