/**
 * Small integrations with other modules, used by lobby buttons and map waymarks.
 * Each one goes through the other module's public API (game.modules.get(id).api) and
 * degrades to a notice when that module isn't active.
 */
import { MODULE_ID } from "./defaults.js";
import { Lobby } from "./lobby.js";

const QUEST = "quest-board";
const REL = "stylish-relationship-tracker";

function apiOf(id) {
  const mod = game.modules.get(id);
  return mod?.active ? mod.api ?? null : null;
}

/** Views offered for the Relationship Tracker action. */
export const RELATIONSHIP_VIEWS = {
  picker: "Character picker",
  mine: "My character's relationships",
  actor: "A specific character (drag an Actor)",
  orgs: "Organizations / factions"
};

/** Quest Board: open only the Quest Log. */
export async function openQuestLog() {
  const api = apiOf(QUEST);
  if (!api?.openLog) return ui.notifications.warn("The Quest Board module isn't active in this world.");
  return api.openLog();
}

/** Stylish Relationship Tracker, in the chosen view. */
export async function openRelationships(action = {}) {
  const api = apiOf(REL);
  if (!api?.open) return ui.notifications.warn("Stylish Relationship Tracker isn't active in this world.");
  switch (action.view) {
    case "orgs":
      return api.openOrganizations?.();
    case "mine": {
      const ch = game.user.character;
      return ch ? api.openForActor(ch) : api.open();
    }
    case "actor":
      return action.uuid ? api.openForActor(action.uuid) : api.open();
    default:
      return api.open();
  }
}

export function registerIntegrations() {
  game.settings.register(MODULE_ID, "questLogHideBoard", {
    name: "Quest Log from the lobby: hide its Quest Board button",
    hint: "While the lobby is showing, players who open the Quest Log won't see the button that jumps to the Quest Board.",
    scope: "world", config: true, type: Boolean, default: true
  });

  // The Quest Log window has its own "Quest board" button; hide it for players while the lobby is up.
  Hooks.on("renderQuestLog", (app, element) => {
    if (game.user.isGM || !game.settings.get(MODULE_ID, "questLogHideBoard")) return;
    if (!Lobby.el) return;
    const root = element instanceof HTMLElement ? element : element?.[0];
    const btn = root?.querySelector?.('[data-action="board"]');
    if (btn) btn.style.display = "none";
  });
}
