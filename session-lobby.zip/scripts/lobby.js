import { MODULE_ID, defaultsFor } from "./defaults.js";
import { renderLobby, renderQuote, buildTokens, fmt, esc } from "./render.js";
import { renderGrimoire, renderCalWidget, renderCalendarModal, fmtTime } from "./grimoire.js";
import { calendarState } from "./calendar.js";
import { Shops } from "./shops.js";

const { mergeObject, deepClone, getProperty } = foundry.utils;

/** Controls the full-screen lobby overlay on this client. */
export class Lobby {
  static el = null;
  static pill = null;
  static previewData = null;   // unsaved data from the designer
  static hiddenForMe = false;  // local "hide/minimize"
  static forced = false;       // local peek while the session is live
  static quoteIndex = 0;
  static #tick = null;
  static #quoteTimer = null;
  static #lastQuoteSwap = 0;

  /* ------------------------------------------------------------------ */
  /*  Data                                                                */
  /* ------------------------------------------------------------------ */

  static get store() {
    return game.settings.get(MODULE_ID, "store");
  }

  static get live() {
    return game.settings.get(MODULE_ID, "sessionLive");
  }

  /** Active layout merged over defaults so older saves gain new fields. */
  static get data() {
    if (this.previewData) return this.previewData;
    const store = this.store;
    const layout = store.layouts?.[store.active] ?? Object.values(store.layouts ?? {})[0];
    return mergeObject(defaultsFor(layout?.template), deepClone(layout ?? {}), { inplace: false, insertKeys: true, overwrite: true });
  }

  static get context() {
    const d = this.data;
    const players = game.users.filter((u) => !u.isGM).map((u) => ({ id: u.id, name: u.name, active: u.active }));
    return {
      now: new Date(),
      locale: game.i18n.lang,
      players,
      world: game.world.title,
      music: this.#currentMusic(),
      isGM: game.user.isGM,
      live: this.live,
      preview: !!this.previewData,
      canMinimize: d.options?.playersCanMinimize !== false,
      quoteIndex: this.quoteIndex,
      cal: d.calendar ? this.calendar(d) : null,
      track: this.#currentTrack(),
      volume: this.#volume(),
      shopsOpen: Shops.available ? Shops.openCount() : 0
    };
  }

  static calendar(d = this.data) {
    try {
      return calendarState(d.calendar, {
        worldTime: game.time?.worldTime ?? 0,
        core: game.time,
        localize: (s) => game.i18n.localize(s)
      });
    } catch (err) {
      console.warn(`${MODULE_ID} | calendar`, err);
      return null;
    }
  }

  static #volume() {
    try { return game.settings.get("core", "globalPlaylistVolume"); } catch { return 0.5; }
  }

  /** First playing sound, with its playlist and progress. */
  static #currentTrack() {
    if (this.data.options?.showMusic === false) return null;
    for (const pl of game.playlists?.playing ?? []) {
      const s = pl.sounds.find((x) => x.playing);
      if (!s) continue;
      const current = Number(s.sound?.currentTime) || 0;
      const duration = Number(s.sound?.duration) || 0;
      return { name: s.name, playlist: pl.name, playing: true, current, duration,
        progress: duration ? Math.min(1, current / duration) : 0, playlistId: pl.id };
    }
    return null;
  }

  static #currentMusic() {
    if (this.previewData?.options?.showMusic === false || this.data.options?.showMusic === false) return "";
    const names = [];
    for (const pl of game.playlists?.playing ?? []) {
      for (const s of pl.sounds) if (s.playing) names.push(s.name);
    }
    return names.join(" · ");
  }

  /* ------------------------------------------------------------------ */
  /*  Visibility                                                          */
  /* ------------------------------------------------------------------ */

  static get shouldShow() {
    if (this.previewData) return true;
    if (this.forced) return true;
    if (this.live) return false;
    return !this.hiddenForMe;
  }

  static refresh() {
    if (this.shouldShow) this.#mount();
    else this.#unmount();
    this.#updatePill();
    Hooks.callAll("sessionLobbyRefresh", !!this.el);
  }

  static #mount() {
    if (!this.el) {
      this.el = document.createElement("div");
      this.el.id = "session-lobby";
      document.body.appendChild(this.el);
      this.el.addEventListener("click", (ev) => this.#onClick(ev));
      this.el.addEventListener("keydown", (ev) => {
        if ((ev.key === "Enter" || ev.key === " ") && ev.target.matches?.('[role="button"]')) {
          ev.preventDefault();
          ev.target.click();
        }
      });
      this.el.addEventListener("input", (ev) => {
        if (!ev.target.matches("[data-sl-volume]")) return;
        const v = Number(ev.target.value);
        clearTimeout(this._volTimer);
        this._volTimer = setTimeout(() => game.settings.set("core", "globalPlaylistVolume", v).catch(() => {}), 120);
      });
      window.addEventListener("resize", this.#rescale);
      this.#tick = setInterval(() => this.#onTick(), 1000);
      this.#lastQuoteSwap = Date.now();
    }
    const modalOpen = this.el.querySelector(".sl-modal-root")?.innerHTML;
    const d = this.data, ctx = this.context;
    this.el.dataset.template = d.template || "skyterm";
    this.el.innerHTML = d.template === "grimoire" ? renderGrimoire(d, ctx) : renderLobby(d, ctx);
    if (modalOpen) this.el.querySelector(".sl-modal-root").innerHTML = modalOpen;
    this.#rescale();
  }

  static #unmount() {
    if (!this.el) return;
    const el = this.el;
    this.el = null;
    clearInterval(this.#tick);
    window.removeEventListener("resize", this.#rescale);
    el.classList.add("sl-leaving");
    setTimeout(() => el.remove(), 420);
  }

  static #rescale = () => {
    const stage = this.el?.querySelector(".sl-stage");
    if (!stage) return;
    // Leave the sidebar uncovered while designing (to drag documents) or when the layout asks for it.
    let right = 0;
    if (this.previewData || this.data.options?.showSidebar) {
      const sb = document.getElementById("sidebar");
      const r = sb?.getBoundingClientRect();
      if (r && r.width) right = Math.max(0, window.innerWidth - r.left);
    }
    this.el.style.right = `${right}px`;
    const s = Math.min(this.el.clientWidth / 1920, this.el.clientHeight / 1080);
    stage.style.setProperty("--sl-scale", s);
  };

  static rescale() {
    this.#rescale();
  }

  static #updatePill() {
    const want = !this.el && !this.live && this.hiddenForMe;
    if (want && !this.pill) {
      this.pill = document.createElement("button");
      this.pill.id = "session-lobby-pill";
      this.pill.type = "button";
      this.pill.innerHTML = `<i class="fa-solid fa-door-open"></i> Open Lobby`;
      this.pill.addEventListener("click", () => { this.hiddenForMe = false; this.refresh(); });
      document.body.appendChild(this.pill);
    } else if (!want && this.pill) {
      this.pill.remove();
      this.pill = null;
    }
  }

  /** Called once per second: refresh clock-ish text without re-rendering. */
  static #onTick() {
    if (!this.el) return;
    const d = this.data;
    const tokens = buildTokens(d, this.context);
    for (const node of this.el.querySelectorAll("[data-fmt]")) {
      const v = fmt(node.dataset.fmt, tokens);
      if (node.textContent !== v) node.textContent = v;
    }
    this.#tickMusic();
    this.#tickSlides();
    const q = d.quotes;
    const interval = Math.max(3, Number(q?.interval) || 9) * 1000;
    if (q?.show && q.items?.length > 1 && Date.now() - this.#lastQuoteSwap > interval) {
      this.#lastQuoteSwap = Date.now();
      this.nextQuote();
    }
  }

  static nextQuote() {
    this.quoteIndex++;
    const node = this.el?.querySelector(".sl-quote");
    if (node) node.outerHTML = renderQuote(this.data.quotes, this.quoteIndex);
  }

  /** Crossfade to the next character image when its time is up. */
  static #tickSlides() {
    for (const box of this.el?.querySelectorAll(".sl-slides") ?? []) {
      const slides = box.querySelectorAll(".sl-slide");
      if (slides.length < 2) continue;
      const now = Date.now();
      const last = Number(box.dataset.last) || (box.dataset.last = now);
      if (now - last < Number(box.dataset.slideSecs) * 1000) continue;
      box.dataset.last = now;
      const cur = [...slides].findIndex((x) => x.classList.contains("active"));
      let next = (cur + 1) % slides.length;
      if (box.dataset.shuffle === "1") {
        do { next = Math.floor(Math.random() * slides.length); } while (next === cur);
      }
      slides[cur]?.classList.remove("active");
      slides[next].classList.add("active");
      const vid = slides[next].querySelector("video");
      if (vid) { vid.currentTime = 0; vid.play().catch(() => {}); }
    }
  }

  static #tickMusic() {
    const bar = this.el?.querySelector("[data-music-bar]");
    if (!bar) return;
    const tr = this.#currentTrack();
    bar.style.width = `${Math.round((tr?.progress || 0) * 100)}%`;
    this.el.querySelector("[data-music-cur]").textContent = fmtTime(tr?.current);
    this.el.querySelector("[data-music-dur]").textContent = fmtTime(tr?.duration);
  }

  static updateCalendar() {
    if (!this.el) return;
    const d = this.data;
    const cal = this.calendar(d);
    if (!cal) return;
    const w = this.el.querySelector(".gr-cal");
    if (w) w.outerHTML = renderCalWidget(cal, d.calendar);
    const modal = this.el.querySelector(".gr-cal-modal");
    if (modal) modal.outerHTML = renderCalendarModal(cal, d.calendar, game.user.isGM);
  }

  static updateMusic() {
    if (!this.el) return;
    const tr = this.#currentTrack();
    const m = this.data.music;
    const gr = this.el.querySelector(".gr-music");
    if (gr) {
      gr.classList.toggle("playing", !!tr);
      gr.querySelector("[data-music]").textContent = tr?.name || m?.idleText || "";
      gr.querySelector("[data-music-pl]").textContent = tr?.playlist || "";
      const ic = gr.querySelector('[data-sl-music="toggle"] i');
      if (ic) ic.className = `fa-solid ${tr ? "fa-pause" : "fa-play"}`;
      this.#tickMusic();
      return;
    }
    const name = this.#currentMusic();
    const node = this.el.querySelector("[data-music]");
    if (node) node.textContent = name || this.data.topBar?.idleText || "";
    this.el.querySelector(".sl-music")?.classList.toggle("is-playing", !!name);
  }

  /* ------------------------------------------------------------------ */
  /*  Clicks                                                              */
  /* ------------------------------------------------------------------ */

  static async #onClick(ev) {
    const modalRoot = this.el?.querySelector(".sl-modal-root");
    if (ev.target.closest("[data-sl-close]") || ev.target === modalRoot) {
      modalRoot.innerHTML = "";
      return;
    }
    const tool = ev.target.closest("[data-sl-tool]")?.dataset.slTool;
    if (tool) return this.#onTool(tool);
    if (ev.target.closest("[data-sl-cal]")) {
      const cal = this.calendar();
      if (cal) modalRoot.innerHTML = renderCalendarModal(cal, this.data.calendar, game.user.isGM);
      return;
    }
    const secs = ev.target.closest("[data-sl-time]")?.dataset.slTime;
    if (secs && game.user.isGM) return game.time.advance(Number(secs));
    const music = ev.target.closest("[data-sl-music]")?.dataset.slMusic;
    if (music && game.user.isGM) return this.#onMusic(music);

    const path = ev.target.closest("[data-sl-action]")?.dataset.slAction;
    if (!path) return;
    if (path === "quote") { this.#lastQuoteSwap = Date.now(); return this.nextQuote(); }
    const d = this.data;
    const item = path === "cta" ? d.cta
      : path === "hero.button" ? { action: d.hero?.buttonAction, label: d.hero?.buttonLabel }
      : getProperty(d, path);
    if (item?.action) return this.runAction(item.action, item.label ?? item.title ?? item.name);
  }

  static async #onTool(tool) {
    switch (tool) {
      case "edit": {
        const { LobbyDesigner } = await import("./designer.js");
        return LobbyDesigner.open();
      }
      case "start": return this.setLive(true);
      case "end": return this.setLive(false);
      case "hide":
        if (this.previewData) return;
        this.forced = false;
        this.hiddenForMe = true;
        return this.refresh();
    }
  }

  static async #onMusic(cmd) {
    try {
      const playing = game.playlists.playing?.[0];
      if (cmd === "toggle") {
        if (playing) return playing.stopAll();
        const target = this.data.music?.playlistUuid ? await fromUuid(this.data.music.playlistUuid) : game.playlists.contents[0];
        return target?.playAll?.();
      }
      if (!playing) return;
      return playing.playNext(undefined, { direction: cmd === "prev" ? -1 : 1 });
    } catch (err) {
      console.error(`${MODULE_ID} | music`, err);
    }
  }

  static async setLive(value) {
    if (!game.user.isGM) return;
    this.forced = false;
    this.hiddenForMe = false;
    await game.settings.set(MODULE_ID, "sessionLive", !!value);
  }

  /** Execute a button's configured action. */
  static async runAction(action, fallbackTitle = "") {
    const type = action?.type || "none";
    try {
      switch (type) {
        case "none": return;
        case "text": return this.showNote(action.title || fallbackTitle, action.content);
        case "url": {
          if (action.url) window.open(action.url, "_blank", "noopener");
          return;
        }
        case "live": return this.setLive(true);
        case "questlog": {
          const { openQuestLog } = await import("./integrations.js");
          return openQuestLog();
        }
        case "relationships": {
          const { openRelationships } = await import("./integrations.js");
          return openRelationships(action);
        }
        case "shops": {
          const { ShopsApp } = await import("./shops.js");
          return ShopsApp.open();
        }
        case "map": {
          const { WorldMap } = await import("./map.js");
          return WorldMap.open();
        }
        case "vault": {
          const { VaultApp } = await import("./vault.js");
          return VaultApp.open();
        }
      }

      if (!action.uuid) return ui.notifications.warn("Session Lobby | This button isn't linked to anything yet.");
      const doc = await fromUuid(action.uuid);
      if (!doc) return ui.notifications.warn("Session Lobby | The linked document no longer exists.");

      if (type === "shop") {
        const { Shops } = await import("./shops.js");
        return Shops.openShop(doc);
      }
      if (type === "macro") return doc.execute?.();
      if (type === "scene") {
        if (!game.user.isGM) return;
        this.forced = false;
        await this.setLive(true);
        return doc.activate?.() ?? doc.view?.();
      }

      // Journals, pages, actors, items: respect permissions.
      const permTarget = doc.documentName === "JournalEntryPage" ? doc.parent : doc;
      if (!permTarget.testUserPermission(game.user, "LIMITED")) {
        return ui.notifications.info(`${fallbackTitle || doc.name}: not available yet.`);
      }
      // Pages the user can't fully see, or players with only LIMITED: show inline.
      if (doc.documentName === "JournalEntryPage") {
        await doc.parent.sheet.render(true, { pageId: doc.id });
      } else {
        await doc.sheet.render(true);
      }
      this.#raise(doc.documentName === "JournalEntryPage" ? doc.parent.sheet : doc.sheet);
    } catch (err) {
      console.error(`${MODULE_ID} | action failed`, err);
      ui.notifications.error("Session Lobby | That button failed — see console (F12).");
    }
  }

  /** Make sure opened windows sit on top of the overlay. */
  static #raise(app) {
    setTimeout(() => {
      app?.bringToFront?.();
      const el = app?.element?.[0] ?? app?.element;
      if (el instanceof HTMLElement) {
        const z = Number(getComputedStyle(el).zIndex) || 0;
        if (z <= 90) el.style.zIndex = 100;
      }
    }, 50);
  }

  static async showNote(title, content) {
    if (!this.el) return;
    const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
    const html = await TE.enrichHTML(content || "", { secrets: game.user.isGM });
    this.el.querySelector(".sl-modal-root").innerHTML = `
      <div class="sl-modal" role="dialog">
        <header><h2>${esc(title)}</h2><div role="button" tabindex="0" data-sl-close aria-label="Close">✕</div></header>
        <div class="sl-modal-body">${html}</div>
      </div>`;
  }

  /* ------------------------------------------------------------------ */
  /*  Preview from the designer                                           */
  /* ------------------------------------------------------------------ */

  static preview(data) {
    this.previewData = data;
    this.refresh();
  }

  static endPreview() {
    this.previewData = null;
    this.refresh();
  }
}
